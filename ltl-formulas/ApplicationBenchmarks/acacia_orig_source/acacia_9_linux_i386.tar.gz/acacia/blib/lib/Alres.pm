package Alres;

use 5.010000;
use strict;
use warnings;
use Utils;


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use alres ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw() ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	
);

our $VERSION = '0.01';

=head1 NAME

alres - AntiChains for LTL REalizability and Synthesis

=head1 SYNOPSIS



=head1 DESCRIPTION

Stub documentation for alres, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Naiyong Jin, E<lt>naiyjin@localdomainE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2008 by Naiyong Jin

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.10.0 or,
at your option, any later version of Perl 5 you may have available.


=cut

# Preloaded methods go here.

use strict;
use LTL;
use LTL2AUT;
use Buechi;
use BuechiAL;
use CoBuechiTree;
use Utils;


######################################################################
# Build a new synthesizer. It stores the configuration and all
# intermediate results.
######################################################################
sub new {
    my $class = shift;
    my %params = @_;

    #Read mentatory parameter
    return undef unless defined $params{formula};
    return undef unless defined $params{partition};
    
    #Read optional parameter and supply default values if needed.
    $params{directory} = "" unless defined $params{directory};
    $params{name} = "synthesis" unless defined $params{name};
    $params{prefix} = "ltl2vl" unless defined $params{prefix};
    $params{simplify} = 1 unless defined $params{simplify};
    $params{method} = "Boolean" unless defined $params{method};
    $params{verbose} = 1 unless defined $params{verbose};
    $params{optimize_nbw} = 1 unless defined $params{optimize_nbw};
    $params{in_use_aa} = "UCT" unless defined $params{in_use_aa};
    $params{optimize_uct} = 1 unless defined $params{optimize_uct};
    $params{optimize_witness} = 1 unless defined $params{optimize_witness};
    $params{optimize_edges} = 1 unless  defined $params{optimize_edges};
    $params{optimize_release} = 1 unless defined $params{optimize_release};
    $params{optimize_reuse} = 1 unless defined $params{optimize_reuse};
    $params{minK} = 0 unless defined $params{minK};    
    $params{maxK} = 20 unless defined $params{maxK};    

    # Make debug directory
    system ("mkdir ".$params{directory}) if (($params{directory} ne "") and
					(not -d $params{directory}));

    my $self = {
			formula   => $params{formula},   #stores phi										formula   => $formula, 
			partition => $params{partition}, #stores the IO-partition       partition => \%partition,                                       
			name      => $params{name},      #name of the generated module  name      => $ltlfile,                 
			directory => $params{directory}, #debug directory               directory => $synthesisDir,                
			prefix    => $params{prefix},    #prefix of output files        prefix    => $prefix,                      
			simplify  => $params{simplify},  #NBW option                    simplify  => $simplify,                    
			method    => $params{method},    #NBW option                    method    => $method,                      		
                                                                                
			optimize_witness => $params{optimize_witness},                  
			optimize_nbw => $params{optimize_nbw},                     
			optimize_uct => $params{optimize_uct},                              
			optimize_edges => $params{optimize_edges},                          
			optimize_release => $params{optimize_release},                      
			optimize_reuse => $params{optimize_reuse},                          
			verbose   => $params{verbose},                                      

			assume    => undef,            #holds automaton for the assumption
			nbw       => undef,            #holds automaton for not phi
			nbw_tl    => undef,            #holds transition labeled nbw
			uct => undef,

	    # added by nyjin 
	    r_ins => undef,									#storing the reference of the array of input variables
	    r_ous => undef,                 #storing the reference of the array of output variables
	    r_io_id_maps => undef,
	    game_trans => undef,  						#storing the predicate for q --s-> q', it differes from delta
	                                      #in that here the s ranges over ins or outs. 

			gfga => undef,      
	    gfga_inits => undef,
	    gfga_finSt =>undef,
	    gfga_q_o => undef,
	    gfga_q_i =>undef,
	    gfga_delta => undef,
      gfga_trans_id => 0,
      gfga_n_q_nu_id => undef,
			gfga_q_nu_names => undef,
			gfga_prohibit => undef,

			state_tgts => undef,
			ary => undef,      
			n_crnt_K => $params{minK},
			maxK => $params{maxK} 
		};

    print "Optimizations:\n";
    print "Edges:".$$self{optimize_edges}." ";
    print "Release:".$$self{optimize_release}." ";
    print "Reuse:".$$self{optimize_reuse}." ";
    return bless $self, $class;
}

######################################################################
# Takes a state-labeled Buechi automaton and stores it.
######################################################################
sub SetNBW {
  my ($self,$aut) = @_;

  if ($$aut{fair}->Size != 1) {
		$aut = $aut->CountingConstruction;
  }
  $$self{nbw} = $aut;
}

######################################################################
# Takes a state-labeled Buechi automaton and stores it.
######################################################################
sub SetTransitionLabeledNBW {
    my ($self,$aut) = @_;
    my $debugdir = $$self{directory};
    my $verb = $$self{verbose};
    my $optimize = $$self{optimize_nbw};

    $aut->DirectSimulationMinimization if $optimize;
    $aut->FairSimulationMinimization if $optimize;

    $$self{nbw_tl} = $aut;
    print $aut->ToString."\n";
    if ($verb > 1) {
			open( NBW, ">$debugdir"."nbw.dot" );
			print NBW $aut->ToDot("NBW");
			close NBW;
			Utils::dot2ps($debugdir."nbw.dot");
    }
}


######################################################################
#   Time out handler
######################################################################
sub timeouthandler {
    my $sig = shift;
    print "CPU time: > 3600 seconds (timeout)\n";
    exit 0;
}
# Required return value.


######################################################################
# Builds an NBW that recognizes all satisfiable input traces of phi
######################################################################
sub BuildPureAssumption {
    my ($self, $verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $formula = $$self{formula};
    my $simplify = $$self{simplify};
    my $method  = $$self{method};
    my $optimize = $$self{optimize_nbw};
    my $debugdir = $$self{directory};
    my $partition = $$self{partition};

    my $parsetree = LTL->new($formula);
    my $normalized = $parsetree->Normalize;
    $normalized = $normalized->Simplify if $simplify;
    print "Build word automaton for ";
    print $normalized->ToString, "\n";

    my $aut = LTL2AUT->new(formula => $normalized, method => $method);
    print "Stats NBW (phi): ", $aut->Stats, "\n";

    #project automaton to input signals
    my $outputs = Set->new;
    my $inputs  = "";
    foreach (keys %{$partition}) {
			if ($$partition{$_} eq 2) { #output variable
		    $outputs->Push($_);
			} else {
		    $inputs .= "$_ ";
			}
    }
    $aut->Project($outputs);
    $aut->Optimize($verb) if $optimize;
    print "Stats NBW (project): ", $aut->Stats, "\n";

    return $aut;
}


######################################################################
# Build an NBW automaton for the negation of the formula.
######################################################################
sub BuildNBW {
    my ($self, $verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $formula = $$self{formula};
    my $prefix  = $$self{prefix};
    my $simplify = $$self{simplify};
    my $method  = $$self{method};
    my $optimize = $$self{optimize_nbw};
    my $debugdir = $$self{directory};
    my $partition = $$self{partition};
    
    print "formula: ", $formula, "\n", '-' x 70, "\n";
    #invert formula and build optimized NBW
    my $negformula = "!(".$formula.")";

    my $parsetree = LTL->new($negformula);
    print $parsetree->ToString, "\n" if $verb > 1;
    print $parsetree->ToDot($negformula) if $verb > 3;

    my $normalized = $parsetree->Normalize;
    $normalized = $normalized->Simplify if $simplify;

    print "Build word automaton for ";
    print $normalized->ToString, "\n";
    if ($normalized eq LTL->new("TRUE")) {
			print "Formula is not satisfiable\n";
			exit;
    }
    if ($normalized eq LTL->new("FALSE")) {
			print "Formula is valid and so trivially realizable\n";
			exit;
    }
    my $result = LTL2AUT->new(formula => $normalized, method => $method);
    $result->Optimize($verb) if $optimize;
#    $result->CheckTypes; #DEBUG
    print "Stats NBW (not phi): ", $result->Stats, "\n";
    
    if ($verb > 1) { 
			open(BUECHI, ">$debugdir"."buechi.dot");
			print BUECHI $result->ToDot($negformula);
			close BUECHI;
			Utils::dot2ps($debugdir."buechi.dot");
			open BUECHI, ">$debugdir"."buechi.aut";
			print BUECHI $result->ToString;
			close BUECHI;
			my $al=BuechiAL->fromBuechi($result);
			open( BUECHI, ">$debugdir"."buechi-al.dot");
			print BUECHI $al->ToDot($negformula);
			close BUECHI;
    }
    print "Stats NBW: ", $result->Stats, "\n";
    print "Build NBW done\n";
    $$self{nbw} = $result;
    return 1;
}

######################################################################
# Apply Counting Construction (if necessary) to get a single fairness
# condition.
######################################################################
sub ApplyCountingConstruction {
    my $self = shift;
    my $result  = $$self{nbw};
    my $verb   = $$self{verbose};
    my $optimize = $$self{optimize_nbw};

    if ($result && $result->{fair}->Size > 1) {
	print "Apply counting construction to reduce ";
	print "the fairness conditions to a single one.\n";
	my $ccresult  = $result->CountingConstruction;
	$ccresult->Optimize($verb) if ($optimize && ($result ne $ccresult));
	$$self{nbw} = $ccresult;
	print "Stats NBW (after cc): ", $result->Stats, "\n";
    }

    #check if nbw = false
    if ($$self{nbw}->IsEmpty) {
	print "Phi is trivially realizable (under the given input assumption)\n";
	return "";
    }
    return 1;
}

######################################################################
# Takes a state-labeled NBW and translates it to a transition labeled
# NBW. Returns 1 if the translation was possible, otherwise "".
######################################################################
sub BuildTransitionLabeledNBW {
    my ($self,$verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $nbw = $self->GetNBW;
    my $name   = $$self{name};
    my $debugdir  = $$self{directory};
    my $optimize = $$self{optimize_nbw};
    
    print "NBW(state-labeled) -> NBW(transition labeled)...\n";

    #Create and check  fairness condition
    if ( $$nbw{fair}->Size == 0 ) {
			# all states are accepting
			foreach my $state ($$nbw{states}) {
	    	$$nbw{fair}->Push($state);
			}
    }
    if ( $$nbw{fair}->Size != 1 ) {
			print "Fair set size not equal to 1\n";
			print "Abort BuildTransitionLabeledNBW\n";
			return "";
    }

    my $bl =  BuechiAL->fromBuechi($nbw);
    $bl->DirectSimulationMinimization if $optimize;
    $bl->FairSimulationMinimization if $optimize;
    
    if ($verb > 1) {
			open( NBW, ">$debugdir"."nbw.dot" );
			print NBW $bl->ToDot("! ".$name);
			close NBW;
			Utils::dot2ps($debugdir."nbw.dot");
			open NBW, ">$debugdir"."nbw.l2a";
			print NBW $bl->ToString;
			close NBW;
    }
    #print states - name -table
    if ($verb > 2) {
			my $states = $$bl{states};
			my $names = $$bl{names};
			foreach my $state (values %$states) {
	  	  print $$names{$state}." -> ".$state->ToString."\n";
			}
    }

    $$self{nbw_tl} = $bl;
    print "NBW (state) -> NBW (trans) done\n";
    print "Stats NBW: ", $bl->Stats, "\n";
    return 1;
}

######################################################################
# Prepare for the Game given the input/output variable context
######################################################################
sub BuildGameContext {
	my $self = shift;

  my $r_partition = $$self{partition};
    
  my %h_ins = ();
  my %h_ous = ();
  my $n_s= 1;
  my $s_var;
  my $n_dir;
  
  my %io_id_maps;
  my %h_part = %{$r_partition};
  my $id;
  while ( ($s_var, $n_dir) = each( %h_part ) ) {
		if ($n_dir == 1){
			$h_ins{$s_var} = $n_s;
    } else {
			$h_ous{$s_var} = $n_s;
    }
    
    $io_id_maps{$n_s} = $s_var;
    $io_id_maps{$s_var} = $n_s;
    $id = 0 - $n_s; 
    $io_id_maps{$id} = "!$s_var";     
    $io_id_maps{"!$s_var"} = $id;
    $n_s++; 
  }

 	($$self{r_ins}, $$self{r_ous}, $$self{r_io_id_maps}) = (\%h_ins, \%h_ous, \%io_id_maps);

  my $in_use_aa = $$self{in_use_aa} eq "NBW" ? $self->GetTransitionLabeledNBW :
									$$self{in_use_aa} eq "UCT" ? $$self{uct} : undef;
  return 0 unless $in_use_aa ;

  my $nodes = $$in_use_aa{states};
  my @tmp_keys = keys (%$nodes);
  my $n_nodes = @tmp_keys;
  $$self{gfga_n_q_nu_id} = $n_nodes + 1; 

  my %new_hash = ();   
  $$self{game_trans} = \%new_hash;
  print "Finish Preparing The Context for Realizability Test.\n";
  return 1;
}

sub CreateGoodForGameNBW {
	my $self = shift;
	my $nbw = $self->GetTransitionLabeledNBW;
  return 0 unless $nbw ;
	
  my $r_nodes = $$nbw{states};
  my $fair = $$nbw{fair};
  my $names = $$nbw{names};
  my $labels = $$nbw{labels};
  my $delta = $$nbw{delta};
  my $init = $$nbw{init};
  
  my %initSt = ();
  my %ucw_delta = ();
	my %finSt = ();
  foreach my $fairset (values %{$fair}) {
		foreach my $node (values %{$fairset}) {
			my $name = $$names{$node};
      $finSt{$name} = 1;
		}
	} # end of processing accepting states
	
	my %init_idx = ();
	my %states_2 = ();
	my %states_1 = ();
	my @nodes = sort (values %{$r_nodes});
	my @sigma_2 = ();
	my @sigma_1 = ();
	my %node_pairs = ();

  foreach my $node (@nodes) {
		my $src_name = $$names{$node};
    
    $initSt{$src_name} = 1 if $init->IsMember($node);
    $states_2{$src_name} = 1;
    
		my @i_2_o = ();
    my $next = $$delta{$node};
    foreach my $succ (values %{$next}){
			my @o_2_i = ();
      my $slabel = $succ->First->ToString;
      my ($ra_g2, $ra_g1) = $self->SplitGuards($slabel);

      my $st_new = $self->NextState;
      $states_1{$st_new} = 1;

      my $dst = $succ->Second;
      my $dst_name = $$names{$dst};

      $ucw_delta{$src_name.":".$st_new} = $ra_g2;
			push(@i_2_o, $st_new);
      
			$ucw_delta{$st_new.":".$dst_name} = $ra_g1;
			push(@o_2_i, $dst_name);
			$node_pairs{$st_new} = \@o_2_i;
		} #end of processing each transition
		$node_pairs{$src_name} = \@i_2_o;
	} #end of processing each state


  my $idx = -1;
  my @q1 = sort(keys(%states_2));
  foreach my $st (@q1) {
		$idx++;
		next if !defined $initSt{$st};
		if (defined $finSt{$st}) {
			$self->getNextK if ($self->getCurrentK == -1);
	    $init_idx{$idx} =  1;
		} else {
			$init_idx{$idx} = 0;
		}
	}

	$idx = 0;
	my %ary = ();
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  @q1 = sort(keys(%states_1));
	$idx = 0;
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  $$self{gfga_inits} = \%initSt;
  $$self{gfga_finSt} = \%finSt;
  $$self{gfga_q_o} = \%states_1;
  $$self{gfga_q_i} = \%states_2;
  $$self{gfga_delta} = \%ucw_delta;
  $$self{gfga_index_init} = \%init_idx; 
	$$self{gfga_tgts} = \%node_pairs;
	$$self{ary} = \%ary;
	return 1;
}


sub BuildGoodForGameUCT {
	my $self = @_;

  my  $uct = $$self{uct};
	return 0 if !defined($uct);

  my $nodes = $$uct{states};
  my $fair = $$uct{fair};
  my $names = $$uct{names};
  my $labels = $$uct{labels};
  my $delta = $$uct{delta};
  my $init = $$uct{init};

	my %finSt = ();
  foreach my $fairset (values %{$fair}) {
		foreach my $node (values %{$fairset}) {
			my $name = $$names{$node};
      $finSt{$name} = 1;
		}
	} # end of processing accepting states

  my %initSt = ();
  my %gfga_delta = ();
	my %prohibit = ();
	my %state_i = ();
	my %state_o = ();

	$state_i{"falsenode"} = 1;
  foreach my $node ( values %{$nodes} ) {
		my $src_name = $$names{$node};
    $initSt{$src_name} = 1 if $init->IsMember($node);
    $state_o{$src_name} = 1;

		my $next = $$delta{$node};
		if (!defined $next) {
			print "find a tree leave $src_name";
			next; 
		}; #tr leaves the automaton

		if ($next->Size == 0) {
			print "$src_name-->falsenode\n";
	    next;
		}

		my $st_nu;
    foreach my $labeledPair ( values %{$next} ) {
		  my $slabel = $labeledPair->First->ToString;
		  my ($ra_g2, $ra_g1) = $self->SplitGuards($slabel);

		  my $destSet = $labeledPair->Second;
			my $dst_name = $$names{$destSet};

		  if ( defined $dst_name ) {
				$st_nu = $self->NextState ;
				$state_i{$st_nu} = 1;
				$gfga_delta{$src_name.":".$st_nu} = $ra_g1;
				$gfga_delta{$st_nu.":".$dst_name} = $ra_g2;
				$self->AddTargets($src_name, $st_nu);
				$self->AddTargets($st_nu, $dst_name);
		    $state_i{$st_nu} = 1;
				next;
		   }

		  if ($destSet->Size == 0) {
				my $guard_id = $self->GuardCode("out_player", $ra_g1);				
				$self->AddProhibitGuard($src_name, $guard_id);
				next;
		  }

			$st_nu = $self->NextState;
	    $state_i{$st_nu} = 1;
			$gfga_delta{$src_name.":".$st_nu} = $ra_g1;
			$self->AddaTarget($src_name, $st_nu);
		  if ( $destSet->Size == 1 ) {
				my $destnode = $destSet->Pick;
				my $dst_name = $$names{$destnode->Second}; 

				my $direction = $destnode->First->ToString;
			  my ($dir_i, $dir_o) = $self->SplitGuards($direction);

				$gfga_delta{$st_nu.":".$dst_name} = $dir_i;
				$self->AddaTarget($st_nu, $dst_name);
				next;
		  }

	  	foreach my $succnode ( values %{$destSet} ) {
				my $direction = $succnode->First->ToString;
				my $destnode = $succnode->Second;
				my $dst_name = $$names{$destnode}; 
				if (defined $dst_name) {
				  my ($dir_i, $dir_o) = $self->SplitGuards($direction);
					$gfga_delta{$st_nu.":".$dst_name} = $dir_i;
					$self->AddaTarget($st_nu, $dst_name);
				} 
	    }
		}
  }

  my $idx = -1;
  my @q1 = sort(keys(%state_o));
	my %init_idx = ();
  foreach my $st (@q1) {
		$idx++;
		next if !defined $initSt{$st};
		if (defined $finSt{$st}) {
			$self->getNextK if ($self->getCurrentK == -1);
	    $init_idx{$idx} =  1;
		} else {
			$init_idx{$idx} = 0;
		}
	}

	$idx = 0;
	my %ary = ();
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  @q1 = sort(keys(%state_i));
	$idx = 0;
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  $$self{gfga_inits} = \%initSt;
  $$self{gfga_finSt} = \%finSt;
  $$self{gfga_q_o} = \%state_o;
  $$self{gfga_q_i} = \%state_i;
  $$self{gfga_delta} = \%gfga_delta;
  $$self{gfga_index_init} = \%init_idx; 
	$$self{ary} = \%ary;
	return 1;
}

sub AddaTerget {
	my ($self, $src, $dst) = @_;

	my $state_tgts = $$self{state_tgts};
	if (!defined $state_tgts) {
		my %nu_hash = ();
		$$self{state_tgts} = \%nu_hash;
		$state_tgts = \%nu_hash;
	}

	my %h_st_tgts = %{$state_tgts};
	my $ra_tgts = $h_st_tgts{$src};
	if (!defined $ra_tgts) {
		my @nu_array = ();
		$h_st_tgts{$src} = \@nu_array;
		$ra_tgts = \@nu_array;
	}	

	my @h_fin = @$ra_tgts;
	push(@h_fin, $dst);

	return;
} 


sub AddProhibitGuard {
	my ($self, $st, $n_g_code) = @_;

	my $prohibit = $$self{gfga_prohibit};
	if (!defined $prohibit) {
		my %nu_hash = ();
		$$self{gfga_prohibit} = \%nu_hash;
		$prohibit = \%nu_hash;
	}

	my %h_prohibit = %{$prohibit};
	my $rh_pg = $h_prohibit{$st};
	if (!defined $rh_pg) {
		my %nu_hash = ();
		$h_prohibit{$st} = \%nu_hash;
		$rh_pg = \%nu_hash;
	}	

	my %h_fin = %$rh_pg;
	$h_fin{$n_g_code} = 1;

	return;
} 

sub GuardCode {
	my ($self, $player, $r_guards) = @_;
	my $verb = $$self{verbose};
	my $r_lits = $player eq "out_player" ? $$self{r_ous} : $$self{r_ins};
	my @a_lits = sort @$r_lits;
	
	my @a_guards = @$r_guards;
	my $n_array_len = @a_guards;
	if ($n_array_len != @a_lits) {
		print "error: Guards length does not match: ";
		Utils::print_array($r_guards);
		print "\n";
		return -1;
	}

	my @bits = ();
	foreach my $crt_lit (@a_lits) {
		for (my $i = 0; $i < @a_guards; $i++) {
			if ($crt_lit eq $a_guards[$i]) {
				push(@bits, 1);
				last;
			} elsif ("!".$crt_lit eq $a_guards[$i] ) {
				push(@bits, 0);
				last;
			}  
		}
	}
	
	my $retVal = 0;
	for (my $i = 0; $i < @bits; $i++) {
		$retVal = $retVal * 2 + $bits[$i];
	}

	if ($verb > 2) {
		print "The Id of ";
		Utils::print_array($r_guards);
		print " is $retVal\n";
	}

	return $retVal;
}

sub NextState {
  my $self = shift;
  $$self{gfga_n_q_nu_id}++;
  
  return "b_$$self{gfga_n_q_nu_id}";
}

sub HSigma2Str {
  my ($self, $rh_s_c) = @_;

	my %alf = %$rh_s_c;
	my $alf_str = "";
  my @tmp = keys(%alf);
	return $self->ASigma2Str(\@tmp); 				
}

sub ASigma2Str {
  my ($self, $ra_s_c) = @_;

	my %io_id_maps = %{$$self{r_io_id_maps}};
	my @alf = @$ra_s_c;
	my $alf_str = "";
	my @tmp2 = ();
	for (my $i = 0; $i < @alf; $i++ ) {
		my $s_sig = $io_id_maps{$alf[$i]}; 
		$alf_str .= "_$s_sig";
	}

	return $alf_str; 				
}

sub SplitGuards {
  my ($self, $s_guard) = @_;
  my %io_id_maps = %{$$self{r_io_id_maps}};
	my %ins = %{$$self{r_ins}};
  
	my @in_grds = ();
	my @out_grds = ();

  $s_guard =~ s/[ \t\n]*//;
  my $pattern = "[{},]";
  my $var = "";
  my @words = split(/$pattern/, $s_guard);
	foreach my $word (@words){
		my $neg = 0;
	  if ($word =~ /=1/) {
	    ($var = $word) =~ s/=1//;
	  } elsif ($word =~ /=0/) {
	    ($var = $word) =~ s/=0//;
	    $neg = 1;
	  } else { 
			next;
    }

    my $tmp = $io_id_maps{$var};
    if (!defined($tmp)) {
      $var =~ s/!//;  
			print "$var is not an interface variable ! \n";
      exit(0); 
		}
		
		$tmp = 0 - $tmp if $neg; 
		if ( exists $ins{$var}  ) {
			push(@in_grds, $tmp);	
		} else {
			push(@out_grds, $tmp);
		}
	}
	
	return (\@in_grds, \@out_grds);
}
 
sub PrintGoodForGameAutomaton {
  my ($self,$graphname) = @_;
  
  my $rh_initSt = $$self{gfga_inits};
  my $rh_finSt = $$self{gfga_finSt};
  my $rh_states_o = $$self{gfga_q_o};
  my $rh_states_i = $$self{gfga_q_i};
  my %delta = %{$$self{gfga_delta}};
  
	my $string = qq!digraph "$graphname" {\n!;
  $string .= qq!size = \"11,7.5\";\ncenter = true;\nrotate = 90;\n!;
  $string .= qq!"title" [label=\"$graphname\",shape=plaintext];\n!;

  my %init_sts = %$rh_initSt;
  my %h_finst = %$rh_finSt; 
  for(my $i = 0; $i<2; $i++){
		my %src = $i == 0 ? %$rh_states_i : %$rh_states_o;
		my %tgt = $i == 0 ? %$rh_states_o : %$rh_states_i;
		my $shape = $i == 0 ? "ellipse" : "box";
		my $who = $i==0 ? "in_play:" : "out_play:";
		
		my ($st, $dc, $tg, $dc2) = ();
    while (($st, $dc) = each(%src)) {
    	my $fin = defined ($h_finst{$st}) ? "1" : " ";
    	
    	$string .= qq!"$st" [label=\"$st\\n($fin)\", shape=$shape];\n!;
    	
    	while (($tg, $dc2) = each(%tgt)) {
    		my $r_guards = $delta{$st.":".$tg};
    		next if ! defined( $r_guards );
    		my $guard = $self->GuardToString($r_guards);
    		$string .= qq!"$st" -> "$tg" [label="{$guard}"];\n!;
    	}
    		 	
    	if (defined $init_sts{$st} ) {
    		$string .= qq!"init_$st" [style=invis]\n!;
    		$string .= qq!"init_$st" -> "$st"\n!;
    	}	
    }
	}
	
	$string .= qq!}\n!;
	return $string;
}
	 
sub GuardToString {
	my ($self, $r_guards) = @_;
	my @guards = @$r_guards;
	
	return " " if @guards == 0;
	my %io_id_maps = %{$$self{r_io_id_maps}};
	my $string = "";
	my $f = 1;
	my $tmp;
	foreach my $guard (@guards){
		$tmp = $io_id_maps{$guard};
		$string .= $f ? qq!$tmp! : qq!, $tmp! ;
		$f = 0;
	}	
	
	return $string;
}

######################################################################
# The main process for Realizable Test
######################################################################
sub RealizableTestByAntiChain {
  my $self = shift;

  my ($k, $K) = (0, $self->getMaxK);

  my %h_ins = %{$$self{r_ins}};
  my %h_q_o = %{$$self{gfga_q_o}};
  my %h_q_i = %{$$self{gfga_q_i}};
  my %h_fin = %{$$self{gfga_finSt}};
  my ($n_e, $n_a) = (0, 0);
  my $verb = $$self{verbose};

  open(LOG, ">$$self{directory}antichain.log") if $verb > 2;  
  my $old_file = select(LOG) if $verb > 2;

  my @q_i = sort (keys %h_q_i);
  my @ins = sort (keys %h_ins);
    
	# Calculate the strongest fixpoint   
  my $w_cnclx = "NONE";
  my @a_f_2 = ();
	$k = $self->getNextK;
	print "Start the Realizability Test with k in [$k, $K]\n";  
  my $valid = 0;
	do {
    # Set up the initial AntiChain for EPre
		@a_f_2 = ();

	  for (my $i = 0; $i < @q_i; $i++){
			if ($k == 0) {
				if (defined($h_fin{$q_i[$i]})) {
		  	  push(@a_f_2, -1);
				} else {
		  	  push(@a_f_2, 0);
				}
			} else {
				push(@a_f_2, $k);
			}
	  }

  	my @s_L = ();
  	push(@s_L, \@a_f_2);  
  	my %L = ();
		$L{"dont_care"} = \@s_L;

    $w_cnclx = "NONE";    
    my ($n_L2_c, $n_L2_p, $n_L1_c, $n_L1_p) = (undef, undef, undef, undef);	
  	$n_L2_p = \%L;  
    print "----------------------------------------------------------------------\n" if $verb > 2;
		$self->print_L("Init Config:", "in_play", $n_L2_p) if $verb > 2;

		while (1){
 			$n_L1_c = $self->PreOut($n_L2_p);
  		$n_e++;
		  $self->print_L("\nAfter PreOut $n_e:", "out_play", $n_L1_c) if $verb > 2;
	    
      if (defined($n_L1_p)){
				$w_cnclx = $self->CompareResults($n_L1_p, $n_L1_c);
        print "Conclusion: $w_cnclx\n" if $verb > 2;
				if ($w_cnclx eq "NONE") {
					$n_L1_p = $n_L1_c;
				} else {
					last;
				} 
			} else {
					$n_L1_p = $n_L1_c;
			}
			print "----------------------------------------------------------------------\n" if $verb > 2;
		  $n_L2_c = $self->PreIn($n_L1_c);
			$n_a++;
		  $self->print_L("\nAfter PreIn $n_a:", "in_play", $n_L2_c) if $verb > 2;
      $valid = $self->CheckInitIncluded($n_L2_c);	    
      last if !$valid;

      if (defined($n_L2_p)){
				$w_cnclx = $self->CompareResults($n_L2_p, $n_L2_c);
        print "Conclusion: $w_cnclx\n" if $verb > 2;
				if ($w_cnclx eq "NONE") {
					$n_L2_p = $n_L2_c;
				} else {
					last;
				}
			} else {
					$n_L2_p = $n_L2_c;
			}
			print "----------------------------------------------------------------------\n" if $verb > 2;
		} # end for while(1), the strongest fixed point is found 

		$k = $self->getNextK if !$valid;
  } while ($k <= $K && !($w_cnclx eq "FIXED-POINT"));

  select($old_file) if $verb > 2;
  close LOG if $verb > 2;
  if ($valid && $w_cnclx eq "FIXED-POINT") {
 		print "REALIZABLE : With k = $k, after $n_e Pre_out and $n_a Pre_in. \n" ;
  } else {
   	print "UnREALIZABLE : With k = $K, after $n_e Pre_out and $n_a Pre_in. \n" ;
	}

  return 1;
}

sub CompareResults {
  my ($self, $r_l1, $r_l2) = @_;
  my %h_l2 = %$r_l2;
  my @a_l2 = %h_l2;
  return "EMPTYCURRENT" if @a_l2 == 0;

  my %h_l1 = %$r_l1;
  my @a_l1 = %h_l1;
  return "NONE" if (@a_l1 != @a_l2);  

  my ($s1, $s2) = (0, 0);
  my ($ra_fs1, $ra_fs2) = (undef, undef); 

  while (($s1, $ra_fs1) = each(%h_l1)) {
		return "NONE" if ( !exists($h_l2{$s1}) );
		return "NONE" if ( !$self->SameFS($ra_fs1, $h_l2{$s1}) );    
	}

  return "FIXED-POINT";
}

######################################################################
# Calculate the AntiChains of the existential predecessors
######################################################################
sub PreIn {
  my ($self, $r_L) = @_;

  my %L_c = ();
  my %h_ins = %{$$self{r_ins}};
  my @a_ins = sort(keys(%h_ins)); 
	my @f_ins = ();
	for (my $i = 0; $i < @a_ins; $i++){
			$f_ins[$i] = 0;
	}
	my $n_sig_i = 2**@a_ins;

  my $verb = $$self{verbose};
	my %io_id_maps = %{$$self{r_io_id_maps}};

  my %h_L_p = %{$r_L};
  my ($j, $ra_fs, $ra_fsC) = (0, 0, undef); 
  my ($sig, $rh_sig) = (undef, undef); 
  for (my $n_sig = 0; $n_sig < $n_sig_i; $n_sig++) {

    my $i = 0;
	  my %h_sig = ();
		my $str = "";

		Utils::int2binary(\@f_ins, $n_sig);		
		foreach my $lit (@a_ins) {
			my $lit2 .= $f_ins[$i] == 0 ? "!".$lit : $lit ;
 	    $str .= $lit2."_";
			my $id = $io_id_maps{$lit2};
			$h_sig{$id} = 1;
 	    $i++;
		}

    my $ra_fs_p;
	  while (($j, $ra_fs_p) = each(%h_L_p)) {
			$ra_fs = $self->CalculatePreH("in_play", $n_sig, $str, \%h_sig, $ra_fs_p);

      if ($verb > 3) {
				print "H for PreIn with input alphabet $str: ";
      	my @a_fs = @$ra_fs;   
	      for (my $k = 0; $k < @a_fs; $k++){
        	print "(";
  	      Utils::print_array($a_fs[$k]);
        	print ") ";
				}
	      print "\n\n";
			}

      if (!defined($ra_fsC)) { 
      	$ra_fsC = $ra_fs;
			} else {
        $ra_fsC = $self->MaxofIntersection($ra_fsC, $ra_fs);
			} 
    }
  }

	$L_c{"dont_care"} = $ra_fsC ; 	
  return \%L_c;
}

######################################################################
# 
######################################################################
sub PreOut {
  my ($self, $r_L) = @_;

  my %L_c = ();
  my %h_ous = %{$$self{r_ous}};
  my @a_ous = sort(keys(%h_ous));
  my @f_ous = (); 
	for (my $i = 0; $i < @a_ous; $i++){
			$f_ous[$i] = 0;
	}

  my $n_sig_o = 2**@a_ous;
  my $verb = $$self{verbose};
	my %io_id_maps = %{$$self{r_io_id_maps}};

  my %h_L_p = %{$r_L};
  my ($j, $ra_hs, $ra_hsC, $ra_fs_p) = (undef, undef, undef, undef); 
  my ($sig, $rh_sig) = (undef, undef); 

  my $hash_ready = $$self{hash_ready};
  for (my $n_sig = 0; $n_sig < $n_sig_o; $n_sig++) {


    my $i = 0;
    my %h_sig = ();
		my $str = "";
		
		Utils::int2binary(\@f_ous, $n_sig);		
		foreach my $lit (@a_ous) {
			my $lit2 .= $f_ous[$i] == 0 ? "!".$lit : $lit ;
 	    $str .= $lit2."_";
			my $id = $io_id_maps{$lit2};
			$h_sig{$id} = 1;
 	    $i++;
		}

		my %h_nu_fs = ();
	  while (($j, $ra_fs_p) = each(%h_L_p)) {
			$ra_hs = $self->CalculatePreH("out_play", $n_sig, $str, \%h_sig, $ra_fs_p);

			# the following lines for debuging
			if ($verb > 3)  {
				my @a_hs = @$ra_hs;   
				print "H for PreOut with output alphabet $str: ";
	     	for (my $k = 0; $k < @a_hs; $k++){
        	print "(";
					Utils::print_array($a_hs[$k]);
        	print ") ";
				}
					print "\n\n";
			} # end of debug codes
  
      if (defined($ra_hsC)) { 
      	$ra_hsC = $self->MaxofUnion($ra_hsC, $ra_hs);
			} else {
        $ra_hsC = $ra_hs;
			} 
    }
  }

  $L_c{"dont_care"} = $ra_hsC;
  return \%L_c;
} 

sub MaxofIntersection {
	my ($self, $r_fs1, $r_fs2) = @_;
  my $r_f_tmp;
  my @a_f_tmp = () ;
  for (my $i = 0; $i < @$r_fs1; $i++){
		for (my $j =0; $j < @$r_fs2; $j++){
			$r_f_tmp = $self->UnionF($$r_fs1[$i], $$r_fs2[$j]);

			push(@a_f_tmp, $r_f_tmp);
		}
	}

  return $self->AntiChainMax(\@a_f_tmp); 
}

sub UnionF {
	my ($self, $r_f1, $r_f2) = @_;

  my @retVal = ();
  for (my $i = 0; $i < @$r_f1; $i++){	
		if ($$r_f1[$i] > $$r_f2[$i]){
			push(@retVal, $$r_f2[$i]);
		} else {
			push(@retVal, $$r_f1[$i]);
		}
	}

	return \@retVal;
}

sub print_L {
  my ($self, $title, $s_player, $r_L) = @_;

  print $title;

  my %h_state = $s_player =~ /out_play/ ? %{$$self{gfga_q_o}} : %{$$self{gfga_q_i}}; 
  my @a_sts = sort( keys( %h_state) ) ;
  for (my $i = 0; $i < @a_sts; $i++) {
		print " $a_sts[$i] ";
  }
  print "\n";

  my $n_s;
  my $ra_fs;
  my $str_s;
  my %h_L = %$r_L;
  while (($str_s, $ra_fs) = each( %h_L)){
    print " $str_s : ";
    $self->print_fs($ra_fs); 
 		print "\n";
	}

	print "\n";
  return 1; 
}

sub print_fs {
	my ($self, $ra_fs) = @_;
  for (my $i = 0 ; $i < @$ra_fs; $i++) {
    print "( ";
		Utils::print_array($$ra_fs[$i]); 
    print " ) ";
	}
}
 
######################################################################
# Compare two rank functions
# return GT if f1 > f2
# return EQ if f1 == f2
# return LT if f1 < f2
# otherwise return UnComparable
######################################################################
sub CompareF {
	my ($self, $r_f1, $r_f2) = @_;
  
  my $b_pre = @$r_f1[0] > @$r_f2[0] ? "GT" :
              @$r_f1[0] == @$r_f2[0] ? "EQ" :
              "LT";

  my $b_this; 
  for (my $i = 1; $i < @$r_f1; $i++){
		$b_this = @$r_f1[$i] > @$r_f2[$i] ? "GT" :
              @$r_f1[$i] == @$r_f2[$i] ? "EQ" :
              "LT";
    if ($b_pre eq $b_this) {
			next;
    }
   
    if ($b_pre eq "GT" && $b_this eq "LT"){
      return "UnComparable";
    } elsif ($b_pre eq "EQ" && !($b_this eq "EQ") ) {
			$b_pre = $b_this;
		} elsif ($b_pre eq "LT" && $b_this eq "GT") {
      return "UnComparable";
		}
	}  

  return $b_pre;        
}

sub SameFS {
  my ($self, $r_fs1, $r_fs2) = @_;
  my @fs_1 = @$r_fs1;
  my @fs_2 = @$r_fs2;
  my $n_fs_1 = @fs_1;
  my $n_fs_2 = @fs_2;
  return 0 if $n_fs_1 != $n_fs_2;   

  my %with_same = ();
  foreach my $f_2 (@fs_2) {
		$with_same{$f_2} = 0;
  }

  my $find_same;
  foreach my $f_1 (@fs_1) {
    $find_same = "";
		foreach my $f_2 (@fs_2) {
			next if $with_same{$f_2};
      $find_same = $self->CompareF($f_1, $f_2);
      if ($find_same eq "EQ") {
				$with_same{$f_2} = 1;
				last;
			}
		}
	
		return 0 if !($find_same eq "EQ");
  }
  return 1;
}

sub MaxofUnion { 
	my ($self, $ra_h1, $ra_h2) = @_;
  my @a_1 = (); 
  for (my $i = 0; $i < @$ra_h1; $i++) {
		$a_1[$i] = 1;
	}

  my @a_2 = (); 
  for (my $i = 0; $i < @$ra_h2; $i++) {
		$a_2[$i] = 1;
	}

  my $ret = undef;
  for (my $j = 0; $j < @$ra_h2; $j++) {
		next if $a_2[$j] == -1;
		for (my $i = 0; $i < @$ra_h1; $i++)	{
			next if $a_1[$i] == -1;
      
      $ret = $self->CompareF($$ra_h1[$i], $$ra_h2[$j]);
			if ($ret =~ /GT/ || $ret =~ /EQ/){
				$a_2[$j] = -1;
				last;   
			} elsif ($ret =~ /LT/) {
        $a_1[$i] = -1;
      } 
		} # end for $i
  } #end for $j

  my @retVal = ();
  for (my $i = 0; $i < @$ra_h1; $i++){
  	push(@retVal, $$ra_h1[$i]) if $a_1[$i] != -1; 
  }

  for (my $i = 0; $i < @$ra_h2; $i++){
  	push(@retVal, $$ra_h2[$i]) if $a_2[$i] != -1; 
  }

  return \@retVal; 
} 

sub AntiChainMax {
	my ($self, $ra_h) = @_;

  my @a_h = (); 
  for (my $i = 0; $i < @$ra_h; $i++) {
		$a_h[$i] = 1;
	}
	
	my $ret = undef;
  for (my $i = 0; $i < @a_h; $i++) {
    next unless ($a_h[$i] != -1);
		my $r_f1 = $$ra_h[$i];
		for (my $j = $i +1 ; ($a_h[$i] != -1) && ($j < @a_h); $j++) {
			next unless ($a_h[$j] != -1);
				
      $ret = $self->CompareF($r_f1, $$ra_h[$j]);
			if ($ret =~ /GT/ || $ret =~ /EQ/){
				$a_h[$j] = -1;
			} elsif ($ret =~ /LT/) {
        $a_h[$i] = -1;
      } 
 		} # end for $j
	} # end for $i
  
  my @retVal = ();
  for (my $i = 0; $i < @a_h; $i++){
    next unless $a_h[$i] != -1;

    push(@retVal, $$ra_h[$i])
  }
  
	return \@retVal;
}

######################################################################
# Calculate the AntiChains of the existential predecessors
######################################################################
sub CalculatePreH {
  my ($self, $s_player, $n_sig, $str_sig, $rh_sigs, $ra_fs_p) = @_;
  
  my $r_gfga_src = $s_player =~ /out_play/ ? $$self{gfga_q_o} : $$self{gfga_q_i};
	my @a_src = sort (keys( %$r_gfga_src));

	my $r_gfga_tgt = $s_player =~ /out_play/ ? $$self{gfga_q_i} : $$self{gfga_q_o};
	my @a_tgt = sort (keys( %$r_gfga_tgt));

	my %h_trans = %{$$self{game_trans}};
	my %delta = %{$$self{gfga_delta}};
  my %finite = %{$$self{gfga_finSt}};
	my %node_pairs = %{$$self{state_tgts}};
	my %ary = %{$$self{ary}};
	my %prohibits = %{$$self{gfga_prohibit}};
		
	my %h_sigs = %$rh_sigs;	
	my @a_fs_p = @$ra_fs_p;
  my $crtK = $self->getCurrentK;

  my @a_nu_L = ();
	my $ra_nu_L = \@a_nu_L;
  my $verbose = $$self{verbose};

  my $trans_changed = 0;
  my ($ra_f, $n_tmp) = (undef, undef);
  foreach $ra_f (@a_fs_p) {
    my @a_f = @{$ra_f};

		my $go_next = 0;
		if ($s_player eq "out_play") {

			foreach my $q ( @a_src){
				my $idx = $ary{$q};
				next if $a_f[$idx] == -1;

				my $h_pro = $prohibits{$q};
				next if !defined $h_pro;

				if (defined $$h_pro{$n_sig}) {
					$go_next = 1;
					last;
				} 				
			}
		}
		next if $go_next;
   
    my @a_h = ();
    for (my $qi = 0; $qi < @a_src; $qi++) {
      my $q = $a_src[$qi];
      my $fq = defined($finite{$q}) ?  ($crtK == 0 ? -1 : $crtK) : $crtK; 

			my @peers = @{$node_pairs{$q}};
			foreach my $qp (@peers) {	
				my $qj = $ary{$qp};
				my $r_g = $delta{$q.":".$qp};

        my $tr_exists = $h_trans{$q.":".$n_sig.":".$qp};
        if (!defined $tr_exists) {
        	$tr_exists = 1;
					my @guards = @$r_g;
					for (my $i = 0; $i < @guards; $i++) {
						my $tmp_ok = $h_sigs{$guards[$i]}; 
						next if defined($tmp_ok) && $tmp_ok == 1;
						$tr_exists = 0;
						last; 
					}

					$h_trans{$q.":".$n_sig.":".$qp} = $tr_exists;
					$trans_changed = 1;        	
        }
        
        next if !$tr_exists;
        if ($a_f[$qj] == -1){
        	$fq = -1;
	        print "$q.$str_sig->.$qp : $fq\n" if $verbose > 3; 
          last;
        }
        if (defined($finite{$qp})) {
        	 $n_tmp = $a_f[$qj] - 1;
        } else {
        		$n_tmp = $a_f[$qj];
        }
        $fq = $n_tmp if ($fq > $n_tmp);
        print "$q.$str_sig->.$qp : $fq\n" if $verbose > 3;		
			} # end for $qj, h($qj) is evaluated.

			if (defined($finite{$q}) && $fq == 0) {
				$fq = -1;
			} 
      print "f($q)=$fq\n\n" if $verbose > 3;
			push(@a_h, $fq);	
		} # end for $qi, now we have a new rank function.

		push(@{$ra_nu_L}, \@a_h); 
  } # end for @ra_f

  $$self{game_trans} = \%h_trans if $trans_changed;

	return $self->AntiChainMax($ra_nu_L);
}

sub CheckInitIncluded {
	my ($self, $rh_fs) = @_;
  my %h_fs = %$rh_fs;
	my @a_fs = %h_fs;
	return 0 if @a_fs < 1;

	my ($dont_care, $ra_fs, $key, $min) = (undef, undef, undef, undef);
	while (($dont_care, $ra_fs) = each(%h_fs)) {
		my @ara_fs = @$ra_fs;
		my $ValidThis = 0; 
		for (my $i = 0; $i < @ara_fs; $i++) {
			my @crt_f = @{$ara_fs[$i]};
     	my %h_idx = %{ $$self{gfga_index_init} };
			while (($key, $min) = each(%h_idx)){
			  if ($crt_f[$key] >= $min){
			  	$ValidThis = 1;
			  	last;
			  }
			}
    }
		return 0 if !$ValidThis;
	}

	return 1;
}

######################################################################
# To check whether (s, s') is a legal game turn.
# Now, in our case, it always return 1
######################################################################
sub gameTurn {
  return 1;
}

######################################################################
# Return the maximal length of the search w.r.t the sizes of the UCW  
# and the Game
######################################################################
sub getMaxK {
  my $self = shift;
	return $$self{maxK};
}

sub getNextK {
  my $self = shift;
  $$self{n_crnt_K} ++;
	return $$self{n_crnt_K} ;
}

sub getCurrentK {
  my $self = shift;
	return $$self{n_crnt_K};
}

######################################################################
# Takes the stored transition labeled NBW and a partition of the AP
# into IO-signals and translate it to a UCT.
######################################################################
sub BuildUCT {
  my ($self, $verb) = @_;
  $verb = $$self{verbose} unless defined $verb;
  my $bl   = $self->GetTransitionLabeledNBW;
  my $partition = $$self{partition};
  my $name = $$self{name};
  my $debugdir = $$self{directory};
  my $optimize = $$self{optimize_uct};
  my $merge_edges = $$self{optimize_edges};
  my $valid = 1;

  print "NBW -> UCT...\n";
  my $cb = CoBuechiTree->fromBuechi( $bl, $partition, $verb, $merge_edges );
  if ( $cb eq "" ) {
  	$self->WriteOutputfiles("Formula is not realizable.\n");
		return "";
  }
  print "Stats UCT: ", $cb->Stats, "\n";
  $valid = $cb->LostStatesMinimization($verb) if $optimize;
  print "Stats UCT LS: ", $cb->Stats, "\n" if $optimize;
  $self->WriteOutputfiles("Formula is not realizable.\n") if ($valid eq "");

  if ($verb > 1) {
		open( UCT, ">$debugdir"."uct.dot" );
		print UCT $cb->ToDot($name);
		close UCT;
#		Utils::dot2ps($debugdir."uct.dot");
		open UCT,  ">$debugdir"."uct.uct";
		print UCT $cb->ToString;
		close UCT;
  }

  $$self{uct} = $cb;
  print "NBW -> UCT done\n";
	open UCT,  ">$debugdir"."uct.uct";
	print UCT $cb->ToString;
	close UCT;

  return $valid;
}

######################################################################
# Print the stored witness in DOT and VERILOG format to a file.
######################################################################
sub PrintModule {
    my $self = shift;
    my $debugdir = $$self{directory};
    my $prefix = $$self{prefix};
    my $name = $$self{name};

    print "Results can be found in $debugdir$prefix-verilog.v and";
    print " $debugdir$prefix-synthesis.dot\n";
    open(VERILOG,   ">$debugdir" . "$prefix" . "-verilog.v");
    open(SYNTHESIS, ">$debugdir" . "$prefix" . "-synthesis.dot");

    my $witness = $self->GetWitness;
    print SYNTHESIS $witness->ToDot($name);
    Utils::dot2ps("$debugdir" . "$prefix" . "-synthesis.dot");

    my $verilog = $witness->ToVerilog;
    print VERILOG "//$$self{formula}\n";
    print VERILOG $verilog;

    close VERILOG;
    close SYNTHESIS;
}

######################################################################
# Clean the output files to avoid confusion.
######################################################################
sub CleanOutputfiles {
    my $self = shift;
    my $debugdir = $$self{directory};
    my $prefix = $$self{prefix};
    open(VERILOG,   ">$debugdir" . "$prefix" . "-verilog.v");
    open(SYNTHESIS, ">$debugdir" . "$prefix" . "-synthesis.dot");
    close VERILOG;
    close SYNTHESIS;
}

######################################################################
# Write text to the output files
######################################################################
sub WriteOutputfiles {
    my ($self,$text) = @_;
    my $debugdir = $$self{directory};
    my $prefix = $$self{prefix};
    open(VERILOG,   ">$debugdir" . "$prefix" . "-verilog.v");
    open(SYNTHESIS, ">$debugdir" . "$prefix" . "-synthesis.dot");
    print VERILOG $text;
    print SYNTHESIS $text;
    close VERILOG;
    close SYNTHESIS;
}

######################################################################
#
######################################################################
sub GetTransitionLabeledNBW {
    my $self = shift;
    return $$self{nbw_tl} if (defined $$self{nbw_tl});
    die "Transition labeled NBW not computed\n";
}
sub GetNBW {
    my $self = shift;
    return $$self{nbw} if (defined $$self{nbw});
    die "NBW not computed\n";
}

# Autoload methods go after =cut, and are processed by the autosplit program.

sub DESTROY {
	my $self = shift;
	
}

1;
__END__
# Below is stub documentation for your module. You'd better edit it!


