package Acacia;

use 5.010000;
use strict;
use warnings;
use Utils;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use alres ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw() ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	
);

our $VERSION = '0.01';

=head1 NAME

Alres - AntiChains for LTL REalizability and Synthesis

=head1 SYNOPSIS

=head1 DESCRIPTION

Stub documentation for alres, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.

=head1 SEE ALSO

See HOWTO for running Alres

=head1 AUTHOR

Naiyong Jin E<lt>naiyjin@ulb.ac.be<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2008 by
Naiyong Jin, Emmanuel Efiliot, Jean-Francois Raskin, Lorent Doyen

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.10.0 or,
at your option, any later version of Perl 5 you may have available.


=cut

# Preloaded methods go here.

use strict;
use LTL;
use LTL2AUT;
use Buechi;
use BuechiAL;
use BuechiALTree;
#use CoBuechiTree;
use Utils;


######################################################################
# Build a new synthesizer. It stores the configuration and all
# intermediate results.
######################################################################
sub new {
    my $class = shift;
    my %params = @_;

    #Read mentatory parameter
    return undef unless defined $params{formula};
    return undef unless defined $params{partition};
    
    #Read optional parameter and supply default values if needed.
    $params{directory} = "" unless defined $params{directory};
    $params{name} = "synthesis" unless defined $params{name};
    $params{prefix} = "ltl2vl" unless defined $params{prefix};
    $params{simplify} = 1 unless defined $params{simplify};
    $params{method} = "Boolean" unless defined $params{method};
    $params{verbose} = 1 unless defined $params{verbose};
    $params{optimize_nbw} = 1 unless defined $params{optimize_nbw};
    $params{aa_in_use} = "UCT" unless defined $params{aa_in_use};
    $params{optimize_uct} = 1 unless defined $params{optimize_uct};
    $params{optimize_witness} = 1 unless defined $params{optimize_witness};
    $params{optimize_edges} = 1 unless  defined $params{optimize_edges};
    $params{optimize_release} = 1 unless defined $params{optimize_release};
    $params{optimize_reuse} = 1 unless defined $params{optimize_reuse};
    $params{minK} = 0 unless defined $params{minK};    
    $params{maxK} = 20 unless defined $params{maxK};    
		$params{winner} = "mod" unless defined $params{winner};

    # Make debug directory
    system ("mkdir ".$params{directory}) if (($params{directory} ne "") and
					(not -d $params{directory}));

    my $self = {
			formula   => $params{formula},   #stores phi										formula   => $formula, 
			partition => $params{partition}, #stores the IO-partition       partition => \%partition,                                       
			name      => $params{name},      #name of the generated module  name      => $ltlfile,                 
			directory => $params{directory}, #debug directory               directory => $synthesisDir,                
			prefix    => $params{prefix},    #prefix of output files        prefix    => $prefix,                      
			simplify  => $params{simplify},  #NBW option                    simplify  => $simplify,                    
			method    => $params{method},    #NBW option                    method    => $method,                      		
                                                                                
			optimize_witness => $params{optimize_witness},                  
			optimize_nbw => $params{optimize_nbw},                     
			optimize_uct => $params{optimize_uct},                              
			optimize_edges => $params{optimize_edges},                          
			optimize_release => $params{optimize_release},                      
			optimize_reuse => $params{optimize_reuse},                          
			verbose   => $params{verbose},                                      
			assume    => undef,            #holds automaton for the assumption
			nbw       => undef,            #holds automaton for not phi
			nbw_tl    => undef,            #holds transition labeled nbw
			uct => undef,

	    # added by nyjin 
      aa_in_use => $params{aa_in_use},
			winner => $params{winner},

	    r_a => undef,									#storing the reference of the array of input variables
	    r_e => undef,                 #storing the reference of the array of output variables
	    r_io_id_maps => undef,
			alpha_str_a => undef,
		  alpha_lits_a => undef,
			alpha_str_e => undef,
		  alpha_lits_e => undef,

	    gfga_trans => undef,  						#storing the predicate for q --s-> q', it differes from delta
	                                      #in that here the s is a string 
			gfga_delta => undef,
			gfga_inits => undef,
	    gfga_finSt =>undef,
	    gfga_q_e => undef,
	    gfga_q_a =>undef,
      gfga_n_q_nu_id => undef,
			gfga_q_nu_names => undef,
			
			state_tgts => undef,
			ary => undef,      
			n_crnt_K => $params{minK},
			maxK => $params{maxK},

			ra_fix_a => undef,								# The followings are used in strategy extraction				
			ra_fix_e => undef,
			ra_post_fix_a => undef,
			ra_post_fix_e => undef,
			bg_nodes => undef,

			h_moore_st => undef,              # The followings are used in moore machine construction 
			h_moore_trans => undef,
		};

    print "Optimizations:\n";
    print "Edges:".$$self{optimize_edges}." ";
    print "Release:".$$self{optimize_release}." ";
    print "Reuse:".$$self{optimize_reuse}." ";
    return bless $self, $class;
}

######################################################################
# Takes a state-labeled Buechi automaton and stores it.
######################################################################
sub SetNBW {
  my ($self,$aut) = @_;

  if ($$aut{fair}->Size != 1) {
		$aut = $aut->CountingConstruction;
  }
  $$self{nbw} = $aut;
}

######################################################################
# Takes a state-labeled Buechi automaton and stores it.
######################################################################
sub SetTransitionLabeledNBW {
    my ($self,$aut) = @_;
    my $debugdir = $$self{directory};
    my $verb = $$self{verbose};
    my $optimize = $$self{optimize_nbw};

    $aut->DirectSimulationMinimization if $optimize;
    $aut->FairSimulationMinimization if $optimize;

    $$self{nbw_tl} = $aut;
    print $aut->ToString."\n";
    if ($verb > 1) {
			open( NBW, ">$debugdir"."nbw.dot" );
			print NBW $aut->ToDot("NBW");
			close NBW;
			Utils::dot2ps($debugdir."nbw.dot");
    }
}


######################################################################
#   Time out handler
######################################################################
sub timeouthandler {
    my $sig = shift;
    print "CPU time: > 3600 seconds (timeout)\n";
    exit 0;
}
# Required return value.


######################################################################
# Builds an NBW that recognizes all satisfiable input traces of phi
######################################################################
sub BuildPureAssumption {
    my ($self, $verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $formula = $$self{formula};
    my $simplify = $$self{simplify};
    my $method  = $$self{method};
    my $optimize = $$self{optimize_nbw};
    my $debugdir = $$self{directory};
    my $partition = $$self{partition};

    my $parsetree = LTL->new($formula);
    my $normalized = $parsetree->Normalize;
    $normalized = $normalized->Simplify if $simplify;
    print "Build word automaton for ";
    print $normalized->ToString, "\n";

    my $aut = LTL2AUT->new(formula => $normalized, method => $method);
    print "Stats NBW (phi): ", $aut->Stats, "\n";

    #project automaton to input signals
    my $outputs = Set->new;
    my $inputs  = "";
    foreach (keys %{$partition}) {
			if ($$partition{$_} eq 2) { #output variable
		    $outputs->Push($_);
			} else {
		    $inputs .= "$_ ";
			}
    }
    $aut->Project($outputs);
    $aut->Optimize($verb) if $optimize;
    print "Stats NBW (project): ", $aut->Stats, "\n";

    return $aut;
}


######################################################################
# Build an NBW automaton for the negation of the formula.
######################################################################
sub BuildNBW {
    my ($self, $verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $formula = $$self{formula};
    my $prefix  = $$self{prefix};
    my $simplify = $$self{simplify};
    my $method  = $$self{method};
    my $optimize = $$self{optimize_nbw};
    my $debugdir = $$self{directory};
    my $partition = $$self{partition};
    
		my $winner = $$self{winner};

    print "formula: ", $formula, "\n", '-' x 70, "\n";
    #invert formula and build optimized NBW
    my $negformula = $winner eq "mod" ? "!(".$formula.")" : $formula;

    my $parsetree = LTL->new($negformula);
    print $parsetree->ToString, "\n" if $verb > 1;
    print $parsetree->ToDot($negformula) if $verb > 3;

    my $normalized = $parsetree->Normalize;
    $normalized = $normalized->Simplify if $simplify;

    print "Build word automaton for ";
    print $normalized->ToString, "\n";
    if ($normalized eq LTL->new("TRUE")) {
			print "Formula is not satisfiable\n";
			exit;
    }
    if ($normalized eq LTL->new("FALSE")) {
			print "Formula is valid and so trivially realizable\n";
			exit;
    }
    my $result = LTL2AUT->new(formula => $normalized, method => $method);
    $result->Optimize($verb) if $optimize;
#    $result->CheckTypes; #DEBUG
    print "Stats NBW (not phi): ", $result->Stats, "\n";
    
    if ($verb > 1) { 
			open(BUECHI, ">$debugdir"."buechi.dot");
			print BUECHI $result->ToDot($negformula);
			close BUECHI;
			Utils::dot2ps($debugdir."buechi.dot");
			open BUECHI, ">$debugdir"."buechi.aut";
			print BUECHI $result->ToString;
			close BUECHI;
			my $al=BuechiAL->fromBuechi($result);
			open( BUECHI, ">$debugdir"."buechi-al.dot");
			print BUECHI $al->ToDot($negformula);
			close BUECHI;
    }
    print "Stats NBW: ", $result->Stats, "\n";
    print "Build NBW done\n";
    $$self{nbw} = $result;
    return 1;
}

######################################################################
# Apply Counting Construction (if necessary) to get a single fairness
# condition.
######################################################################
sub ApplyCountingConstruction {
    my $self = shift;
    my $result  = $$self{nbw};
    my $verb   = $$self{verbose};
    my $optimize = $$self{optimize_nbw};

    if ($result && $result->{fair}->Size > 1) {
	print "Apply counting construction to reduce ";
	print "the fairness conditions to a single one.\n";
	my $ccresult  = $result->CountingConstruction;
	$ccresult->Optimize($verb) if ($optimize && ($result ne $ccresult));
	$$self{nbw} = $ccresult;
	print "Stats NBW (after cc): ", $result->Stats, "\n";
    }

    #check if nbw = false
    if ($$self{nbw}->IsEmpty) {
	print "Phi is trivially realizable (under the given input assumption)\n";
	return "";
    }
    return 1;
}

######################################################################
# Takes a state-labeled NBW and translates it to a transition labeled
# NBW. Returns 1 if the translation was possible, otherwise "".
######################################################################
sub BuildTransitionLabeledNBW {
    my ($self,$verb) = @_;
    $verb = $$self{verbose} unless defined $verb;
    my $nbw = $self->GetNBW;
    my $name   = $$self{name};
    my $debugdir  = $$self{directory};
    my $optimize = $$self{optimize_nbw};
    
    print "NBW(state-labeled) -> NBW(transition labeled)...\n";

    #Create and check  fairness condition
    if ( $$nbw{fair}->Size == 0 ) {
			# all states are accepting
			foreach my $state ($$nbw{states}) {
	    	$$nbw{fair}->Push($state);
			}
    }
    if ( $$nbw{fair}->Size != 1 ) {
			print "Fair set size not equal to 1\n";
			print "Abort BuildTransitionLabeledNBW\n";
			return "";
    }

    my $bl =  BuechiAL->fromBuechi($nbw);
    $bl->DirectSimulationMinimization if $optimize;
    $bl->FairSimulationMinimization if $optimize;
    
    if ($verb > 1) {
			open( NBW, ">$debugdir"."nbw.dot" );
			print NBW $bl->ToDot("! ".$name);
			close NBW;
#			Utils::dot2ps($debugdir."nbw.dot");
			open NBW, ">$debugdir"."nbw.l2a";
			print NBW $bl->ToString;
			close NBW;
    }

    if ($verb > 2) {
			my $states = $$bl{states};
			my $names = $$bl{names};
			foreach my $state (values %$states) {
	  	  print $$names{$state}." -> ".$state->ToString."\n";
			}
    }

    $$self{nbw_tl} = $bl;
    print "NBW (state) -> NBW (trans) done\n";
    print "Stats NBW: ", $bl->Stats, "\n";
    return 1;
}

######################################################################
# Prepare for the Game given the input/output variable context
######################################################################
sub BuildGameContext {
	my $self = shift;

  my $in_use_aa = $$self{aa_in_use} eq "UCT" ? $$self{uct} : $self->GetTransitionLabeledNBW;
  return 0 unless $in_use_aa ;

  my $r_partition = $$self{partition};
  my $winner = $$self{winner};

  my %h_as = ();
  my %h_es = ();
  my $n_s= 1;
  my $s_var;
  my $n_dir;
  
  my %io_id_maps;
  my %h_part = %{$r_partition};
  my $id;
  while ( ($s_var, $n_dir) = each( %h_part ) ) {
		if ($n_dir == 1){
			if ($winner eq "mod") {
				$h_as{$s_var} = $n_s;
			} else {
				$h_es{$s_var} = $n_s;
			} 
 	  } else {
			if ($winner eq "mod") {
				$h_es{$s_var} = $n_s;
			} else {
				$h_as{$s_var} = $n_s;
			}
 	  }
    
    $io_id_maps{$n_s} = $s_var;
    $io_id_maps{$s_var} = $n_s;
    $id = 0 - $n_s; 
    $io_id_maps{$id} = "!$s_var";     
    $io_id_maps{"!$s_var"} = $id;
    $n_s++; 
  }
 	($$self{r_a}, $$self{r_e}, $$self{r_io_id_maps}) = (\%h_as, \%h_es, \%io_id_maps);

  my $nodes = $$in_use_aa{states};
  my @tmp_keys = keys (%$nodes);
  my $n_nodes = @tmp_keys;
  $$self{gfga_n_q_nu_id} = $n_nodes + 1; 

	$self->BuildAlphabets("a_play");
	$self->BuildAlphabets("e_play");

  my %new_hash = ();   
  $$self{gfga_trans} = \%new_hash;

	my %new_hash2 = ();   
  $$self{gfga_delta} = \%new_hash2;
 
  print "Finish Preparing The Context for Realizability Test.\n";
  return 1;
}

sub BuildTurnBasedAutomaton {
	my $self = shift;

	if ( $$self{aa_in_use} eq "UCT") {
		return $self->BuildTBAFromUCT;
	} elsif ($$self{aa_in_use} eq "NBW")	{
		return $self->BuildTBAFromNBW;
	}

#	return $self->BuildGFGAFromUCT;
}

sub BuildTBAFromNBW {
	my $self = shift;
	my $nbw = $self->GetTransitionLabeledNBW;
  return 0 unless $nbw ;
	
  my $r_nodes = $$nbw{states};
  my $fair = $$nbw{fair};
  my $names = $$nbw{names};
  my $labels = $$nbw{labels};
  my $delta = $$nbw{delta};
  my $init = $$nbw{init};
  
  my %initSt = ();
  my %ucw_delta = ();
	my %finSt = ();
  foreach my $fairset (values %{$fair}) {
		foreach my $node (values %{$fairset}) {
			my $name = $$names{$node};
      $finSt{$name} = 1;
		}
	} # end of processing accepting states
	
	my %state_a = ();
	my %state_e = ();
	my @nodes = sort (values %{$r_nodes});
  foreach my $node (@nodes) {
		my $src_name = $$names{$node};
    $state_e{$src_name} = 1;    

    $initSt{$src_name} = 1 if $init->IsMember($node);
    my $next = $$delta{$node};
    foreach my $succ (values %{$next}){
	    my $slabel = $succ->First->ToString;
      my ($ra_g2, $ra_g1) = $self->SplitGuards($slabel);

      my $st_nu = $self->NextState;
      $state_a{$st_nu} = 1;

      my $dst = $succ->Second;
      my $dst_name = $$names{$dst};

			$self->AddaTarget($src_name, $st_nu);
			$self->AddTransitions("e_play", $src_name, $ra_g1, $st_nu);

			$self->AddaTarget($st_nu, $dst_name);
			$self->AddTransitions("a_play", $st_nu, $ra_g2, $dst_name);
		} #end of processing each transition
	} #end of processing each state

  my $idx = -1;
  my @q1 = sort keys %state_e ;
	my %init_idx = ();
  foreach my $st (@q1) {
		$idx++;
		next if !defined $initSt{$st};
		if (defined $finSt{$st}) {
			$self->getNextK if ($self->getCurrentK == -1);
	    $init_idx{$idx} =  1;
		} else {
			$init_idx{$idx} = 0;
		}
	}

	$idx = 0;
	my %ary = ();
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  @q1 = sort keys %state_a;
	$idx = 0;
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  $$self{gfga_inits} = \%initSt;
  $$self{gfga_finSt} = \%finSt;
  $$self{gfga_q_e} = \%state_e;
  $$self{gfga_q_a} = \%state_a;
  $$self{gfga_index_init} = \%init_idx; 
	$$self{ary} = \%ary;
	return 1;
}

sub BuildTBAFromUCT {
	my $self = shift;

  my  $uct = $$self{uct};
	return 0 if !defined($uct);

	my $verb =  $$self{verbose};
	my $winner = $$self{winner};

  my $nodes = $$uct{states};
  my $fair = $$uct{fair};
  my $names = $$uct{names};
  my $labels = $$uct{labels};
  my $delta = $$uct{delta};
  my $init = $$uct{init};

	my %finSt = ();
  foreach my $fairset (values %{$fair}) {
		foreach my $node (values %{$fairset}) {
			my $name = $$names{$node};
      $finSt{$name} = 1;
		}
	} # end of processing accepting states

  my %initSt = ();
	my %state_a = ();
	my %state_e = ();

	my $falsenode = 0;	
	my @true = ();
  foreach my $node ( values %{$nodes} ) {
		my $src_name = $$names{$node};
    $initSt{$src_name} = 1 if $init->IsMember($node);
		if ($winner eq "mod") {
	    $state_e{$src_name} = 1;
		} else {
		  $state_a{$src_name} = 1;
		}

		my $next = $$delta{$node};
		if (!defined $next) {
			print "find a tree leave $src_name";
			next; 
		}; #tr leaves the automaton

		if ($next->Size == 0) {
			print "$src_name-->falsenode\n";
	    next;
		}

		my $st_nu;
    foreach my $labeledPair ( values %{$next} ) {
		  my $slabel = $labeledPair->First->ToString;
		  my ($ra_ga, $ra_ge) = $self->SplitGuards($slabel);

		  my $destSet = $labeledPair->Second;
			my $dst_name = $$names{$destSet};

		  if ( defined $dst_name ) {
				$st_nu = $self->NextState ;
				if ($winner eq "mod") {
					$state_a{$st_nu} = 1;
				} else {
					$state_e{$st_nu} = 1;
				}

				$self->AddaTarget($src_name, $st_nu);
				$self->AddaTarget($st_nu, $dst_name);

				if ($winner eq "mod") {
					$self->AddTransitions("e_play", $src_name, $ra_ge, $st_nu);
					$self->AddTransitions("a_play", $st_nu, $ra_ga, $dst_name);
				} else {
					$self->AddTransitions("a_play", $src_name, $ra_ga, $st_nu);
					$self->AddTransitions("e_play", $st_nu, $ra_ge, $dst_name);
				}

				next;
		   }

		  if ($destSet->Size == 0) {
				$falsenode = 1;

				$self->AddaTarget($src_name, "falsenode");
				if ($winner eq "mod") {
					$self->AddTransitions("e_play", $src_name, $ra_ge, "falsenode");
				}	else {
					$self->AddTransitions("a_play", $src_name, $ra_ga, "falsenode");
				}
				next;
		  }

			$st_nu = $self->NextState;
			if ($winner eq "mod") {
		    $state_a{$st_nu} = 1;
			} else {
		    $state_e{$st_nu} = 1;
			}

			$self->AddaTarget($src_name, $st_nu);
			if ($winner eq "mod") {
				$self->AddTransitions("e_play", $src_name, $ra_ge, $st_nu);
			}	else {
				$self->AddTransitions("a_play", $src_name, $ra_ga, $st_nu);
			}
		  if ( $destSet->Size == 1 ) {
				my $destnode = $destSet->Pick;
				my $dst_name = $$names{$destnode->Second}; 

				my $direction = $destnode->First->ToString;
			  my ($alf_a, $alf_e) = $self->SplitGuards($direction);

				$self->AddaTarget($st_nu, $dst_name);
				if ($winner eq "mod") {
					$self->AddTransitions("a_play", $st_nu, $alf_a, $dst_name);
				}	else {
					$self->AddTransitions("e_play", $st_nu, $alf_e, $dst_name);
				}
				next;
		  }

	  	foreach my $succnode ( values %{$destSet} ) {
				my $direction = $succnode->First->ToString;
				my $destnode = $succnode->Second;
				my $dst_name = $$names{$destnode}; 
				if (defined $dst_name) {
				  my ($alf_a, $alf_e) = $self->SplitGuards($direction);
					$self->AddaTarget($st_nu, $dst_name);
					if ($winner eq "mod") {
						$self->AddTransitions("a_play", $st_nu, $alf_a, $dst_name);
					}	else {
						$self->AddTransitions("e_play", $st_nu, $alf_e, $dst_name);
					}
				} 
	    } # end for $succnode
		}
  }

	if ($falsenode) {	
    $finSt{"falsenode_x"} = 1;
		if ($winner eq "mod") {
			$state_e{"falsenode_x"} = 1;
			$state_a{"falsenode"} = 1;
			$self->AddaTarget("falsenode", "falsenode_x");
			$self->AddTransitions("a_play", "falsenode", \@true, "falsenode_x");
			$self->AddaTarget("falsenode_x", "falsenode");
			$self->AddTransitions("e_play", "falsenode_x", \@true, "falsenode");
		} else {
			$state_a{"falsenode_x"} = 1;
			$state_e{"falsenode"} = 1;
			$self->AddaTarget("falsenode", "falsenode_x");
			$self->AddTransitions("e_play", "falsenode", \@true, "falsenode_x");
			$self->AddaTarget("falsenode_x", "falsenode");
			$self->AddTransitions("a_play", "falsenode_x", \@true, "falsenode");
		}
	}

  my $idx = -1;
  my @q1 = $winner eq "mod" ? sort keys %state_e : sort keys %state_a;
	my %init_idx = ();
  foreach my $st (@q1) {
		$idx++;
		next if !defined $initSt{$st};
		if (defined $finSt{$st}) {
			$self->getNextK if ($self->getCurrentK == -1);
	    $init_idx{$idx} =  1;
		} else {
			$init_idx{$idx} = 0;
		}
	}

	$idx = 0;
	my %ary = ();
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  @q1 = $winner eq "mod" ? sort keys %state_a : sort keys %state_e;
	$idx = 0;
	foreach my $st (@q1) {
		$ary{$st} = $idx;
		$idx ++;
	}

  $$self{gfga_inits} = \%initSt;
  $$self{gfga_finSt} = \%finSt;
  $$self{gfga_q_e} = \%state_e;
  $$self{gfga_q_a} = \%state_a;
  $$self{gfga_index_init} = \%init_idx; 
	$$self{ary} = \%ary;

	return 1;
}

sub BuildAlphabets {
	my ($self, $player) = @_;
	my %io_id_maps = %{$$self{r_io_id_maps}};
	my %h_sigs = $player eq "a_play" ? %{ $$self{r_a} } : %{ $$self{r_e} };	
	my @a_sigs = sort keys %h_sigs;
	my @bits = ();
	for (my $i = 0; $i < @a_sigs; $i++) {
		$bits[$i] = 0;
	}

	my @alpha_string = ();
	my @alpha_lits = ();
	my $n_alpha = 2**@a_sigs;
	for (my $i = 0; $i < $n_alpha; $i++){
		Utils::int2binary(\@bits, $i);

	  my %h_sigs = ();
		my $str = "";
		my $j = 0;
		foreach my $lit (@a_sigs) {
			my $lit2 = $bits[$j] == 0 ? "!".$lit : $lit ;
			$str .= $lit2."_";
			my $id = $io_id_maps{$lit2};
			$h_sigs{$id} = 1;
 	    $j++;
		}

		push(@alpha_string, $str);
		push(@alpha_lits, \%h_sigs);
	}

	if ($player eq "a_play") {
		$$self{alpha_str_a} = \@alpha_string;
		$$self{alpha_lits_a} = \@alpha_lits;
	} else {
		$$self{alpha_str_e} = \@alpha_string;
		$$self{alpha_lits_e} = \@alpha_lits;
	}
	
	return;
}

sub AddTransitions {
	my ($self, $player, $src, $ra_g, $tgt) = @_;

	my $r_alpha_lits = $player eq "a_play" ? $$self{alpha_lits_a} : $$self{alpha_lits_e};
	my @a_alpha_lits = @$r_alpha_lits;

	my $trans = $$self{gfga_trans};
	my $delta = $$self{gfga_delta};
	my @guards = @$ra_g;

	for (my $i = 0; $i < @a_alpha_lits; $i++){
		my %crt_lits = %{ $a_alpha_lits[$i] };
		my @crt_t = keys %crt_lits;
		my $tr_exists = 1;
		for (my $j = 0; $j < @guards; $j++) {
			my $tmp_ok = $crt_lits{ $guards[$j] }; 
			next if defined($tmp_ok);
			$tr_exists = 0;
			last; 
		}
		$$trans{$src.":".$i.":".$tgt} = 1 if ($tr_exists);
	}

	my $ra_entry = $$delta{$src.":".$tgt};
	if (!defined $ra_entry) {
		my @nu_array = ();
		$$delta{$src.":".$tgt} = \@nu_array;
		$ra_entry = \@nu_array;
	}
	push(@{$ra_entry}, $ra_g);

	return;
}

sub AddaTarget {
	my ($self, $src, $dst) = @_;

	my %nu_hash1 = ();
	my %nu_hash2 = ();
	my $state_tgts = $$self{state_tgts};
	if (!defined $state_tgts) {
		$$self{state_tgts} = \%nu_hash1;
		$state_tgts = \%nu_hash1;
	}

	my $ra_tgts = $$state_tgts{$src};
	if (!defined $ra_tgts) {
		$$state_tgts{$src} = \%nu_hash2;
		$ra_tgts = \%nu_hash2;
	}	

	$$ra_tgts{$dst} = 1;
	return;
} 

sub GuardCode {
	my ($self, $player, $r_guards) = @_;
	my $verb = $$self{verbose};
	my %io_id_maps = %{$$self{r_io_id_maps}};
	my $r_lits = $player eq "e_player" ? $$self{r_e} : $$self{r_a};
	my @a_lits = sort keys %$r_lits;
	
	my @a_guards = @$r_guards;
	my $n_array_len = @a_guards;
	if ($n_array_len != @a_lits) {
		print "error: Guards length does not match: ";
		Utils::print_array($r_guards);
		print "\n";
		return -1;
	}
	my %h_grds = ();
	for (my $i = 0; $i < @a_guards; $i++) {
		my $tmp = $io_id_maps{$a_guards[$i]};
		$h_grds{$tmp} = 1;
	}

	my @bits = ();
	foreach my $crt_lit (@a_lits) {
		if (defined $h_grds{$crt_lit}) {
				push(@bits, 1);
		} elsif (defined $h_grds{"!".$crt_lit}) {
				push(@bits, 0);
		}  
	}
	
	my $retVal = 0;
	for (my $i = 0; $i < @bits; $i++) {
		$retVal = $retVal * 2 + $bits[$i];
	}

	if ($verb > 3) {
		print "The Id of ";
		Utils::print_array($r_guards);
		print " is $retVal\n";
	}

	return $retVal;
}

sub NextState {
  my $self = shift;
  $$self{gfga_n_q_nu_id}++;
  
  return "b_$$self{gfga_n_q_nu_id}";
}

sub HSigma2Str {
  my ($self, $rh_s_c) = @_;

	my %alf = %$rh_s_c;
	my $alf_str = "";
  my @tmp = keys(%alf);
	return $self->ASigma2Str(\@tmp); 				
}

sub ASigma2Str {
  my ($self, $ra_s_c) = @_;

	my %io_id_maps = %{$$self{r_io_id_maps}};
	my @alf = @$ra_s_c;
	my $alf_str = "";
	my @tmp2 = ();
	for (my $i = 0; $i < @alf; $i++ ) {
		my $s_sig = $io_id_maps{$alf[$i]}; 
		$alf_str .= "_$s_sig";
	}

	return $alf_str; 				
}

sub SplitGuards {
  my ($self, $s_guard) = @_;
  my %io_id_maps = %{$$self{r_io_id_maps}};
	my %as = %{$$self{r_a}};
  
	my @a_grds = ();
	my @e_grds = ();

  $s_guard =~ s/[ \t\n]*//;
  my $pattern = "[{},]";
  my $var = "";
  my @words = split(/$pattern/, $s_guard);
	foreach my $word (@words){
		my $neg = 0;
	  if ($word =~ /=1/) {
	    ($var = $word) =~ s/=1//;
	  } elsif ($word =~ /=0/) {
	    ($var = $word) =~ s/=0//;
	    $neg = 1;
	  } else { 
			next;
    }

    my $tmp = $io_id_maps{$var};
    if (!defined($tmp)) {
      $var =~ s/!//;  
			print "$var is not an interface variable ! \n";
      exit(0); 
		}
		
		$tmp = 0 - $tmp if $neg; 
		if ( exists $as{$var}  ) {
			push(@a_grds, $tmp);	
		} else {
			push(@e_grds, $tmp);
		}
	}
	
	return (\@a_grds, \@e_grds);
}
 
sub PrintGoodForGameAutomaton {
  my ($self,$graphname) = @_;
  
  my $rh_initSt = $$self{gfga_inits};
  my $rh_finSt = $$self{gfga_finSt};
  my $rh_states_e = $$self{gfga_q_e};
  my $rh_states_a = $$self{gfga_q_a};
	my %h_trans = %{ $$self{gfga_trans} };
	my %h_delta = %{ $$self{gfga_delta} };

	my $string = qq!digraph "$graphname" {\n!;
  $string .= qq!size = \"11,7.5\";\ncenter = true;\nrotate = 90;\n!;
  $string .= qq!"title" [label=\"$graphname\",shape=plaintext];\n!;

  my %init_sts = %$rh_initSt;
  my %h_finst = %$rh_finSt; 
  for(my $i = 0; $i<2; $i++){
		my %src = $i == 0 ? %$rh_states_a : %$rh_states_e;
		my %tgt = $i == 0 ? %$rh_states_e : %$rh_states_a;
		my $shape = $i == 0 ? "ellipse" : "box";
		my $who = $i==0 ? "a_play:" : "e_play:";
		
		my ($st, $dc, $tg) = ();
    while (($st, $dc) = each(%src)) {
    	my $fin = defined ($h_finst{$st}) ? "1" : " ";
    	$string .= qq!"$st" [label=\"$st\\n($fin)\", shape=$shape];\n!;
    	
    	if (defined $init_sts{$st} ) {
    		$string .= qq!"init_$st" [style=invis]\n!;
    		$string .= qq!"init_$st" -> "$st"\n!;
    	}	
    }
	}
	
  my ($src_tgt, $ra) = (undef, undef);
	while (($src_tgt, $ra) = each(%h_delta)) {
		my @a_grds = @{$ra};
		my ($src, $tgt) = split(":", $src_tgt);

		for (my $i = 0; $i < @a_grds; $i++) {
			my $label = $self->GuardToString($a_grds[$i]);
			$string .= qq!"$src" -> "$tgt" [label="{$label}"]\n!;
		}
	}  

	$string .= qq!}\n!;
	return $string;
}
	 
sub GuardToString {
	my ($self, $r_guards) = @_;
	my @guards = @$r_guards;
	
	return " " if @guards == 0;
	my %io_id_maps = %{$$self{r_io_id_maps}};
	my $string = "";
	my $f = 1;
	my $tmp;
	foreach my $guard (@guards){
		$tmp = $io_id_maps{$guard};
		$string .= $f ? qq!$tmp! : qq!, $tmp! ;
		$f = 0;
	}	
	
	return $string;
}

######################################################################
# The main process for Realizable Test
######################################################################
sub RealizableTestByAntiChain {
  my $self = shift;

	my $winner = $$self{winner};
  my %h_q_s = $winner eq "mod" ? %{$$self{gfga_q_e}} : %{$$self{gfga_q_a}};
  my @q_s = sort (keys %h_q_s);
	
  my ($k, $K) = (0, $self->getMaxK);
  my %h_fin = %{$$self{gfga_finSt}};
  my ($n_e, $n_a) = (0, 0);
  my $verb = $$self{verbose};
	my ($n_maxEpre, $n_maxApre) = (0,0);

  open(LOG, ">$$self{directory}antichain.log") if $verb > 2;  
  my $old_file = select(LOG) if $verb > 2;
    
	# Calculate the strongest fixpoint   
	my ($n_e_c, $n_e_p, $n_a_c, $n_a_p) = (undef, undef, undef, undef);	
  my $w_cnclx = "NONE";
  my @a_f = ();
	$k = $self->getNextK;
	print "Start the Realizability Test with k in [$k, $K]\n";  
 	my $valid = 1;
	do {
		print STDOUT "k= $k \t";
    # Set up the initial AntiChain  
		@a_f = ();

	  for (my $i = 0; $i < @q_s; $i++){
			if ($k == 0) {
				if (defined($h_fin{$q_s[$i]})) {
		  	  push(@a_f, -1);
				} else {
		  	  push(@a_f, 0);
				}
			} else {
				push(@a_f, $k);
			}
	  }

  	my @s_L = ();
  	push(@s_L, \@a_f);  
  	my %L = ();
		$L{"dont_care"} = \@s_L;

    $w_cnclx = "NONE";
		$valid = 1;    
    ($n_e_c, $n_e_p, $n_a_c, $n_a_p) = (undef, undef, undef, undef);	

		if ($winner eq "env") {
	 		$n_a_p = \%L;  
			$self->print_L("Init Config:", "a_play", $n_a_p) if $verb > 2;
			print "----------------------------------------------------------------------\n" if $verb > 2;

			$n_e_c = $self->EPre($n_a_p);
			$n_e++;
			$n_e_p = $n_e_c;

			my @a_tmp = %$n_e_c;
			my $n_size_e = @{ $a_tmp[1] };
			$n_maxEpre = $n_size_e if $n_size_e > $n_maxEpre;
		  $self->print_L("\nAfter EPre $n_e: Size: $n_size_e ", "e_play", $n_e_p) if $verb > 2;
			print "----------------------------------------------------------------------\n" if $verb > 2;

		}else {
	 		$n_e_p = \%L;  
			$self->print_L("Init Config:", "e_play", $n_e_p) if $verb > 2;
			print "----------------------------------------------------------------------\n" if $verb > 2;
		}

		while ($valid){
			$n_a_c = $self->APre($n_e_p);
			$n_a++;
			my @a_tmp = %$n_a_c;
			my $n_size_a = @{ $a_tmp[1] };
			$n_maxApre = $n_size_a if $n_size_a > $n_maxApre;

		  $self->print_L("\nAfter APre $n_a: Size: $n_size_a", "a_play", $n_a_c) if $verb > 2;
			print "----------------------------------------------------------------------\n" if $verb > 2;
			if ($winner eq "env") {
				$valid = $self->CheckInitIncluded($n_a_c);	    
  	    last if !$valid;
			}

			if (defined($n_a_p)){
				$w_cnclx = $self->CompareResults($n_a_p, $n_a_c);
        print "Conclusion: $w_cnclx\n" if $verb > 2;
				print "----------------------------------------------------------------------\n" if $verb > 2;
				if ($w_cnclx eq "NONE") {
					$n_a_p = $n_a_c;
				} else {
					last;
				} 
			} else {
				$n_a_p = $n_a_c;
			}

			$n_e_c = $self->EPre($n_a_p);
			$n_e++;
			@a_tmp = %$n_e_c;
			my $n_size_e = @{ $a_tmp[1] };
			$n_maxEpre = $n_size_e if $n_size_e > $n_maxEpre;
		  $self->print_L("\nAfter EPre $n_e: Size: $n_size_e ", "e_play", $n_e_p) if $verb > 2;
			print "----------------------------------------------------------------------\n" if $verb > 2;

			if ($winner eq "mod") {
				$valid = $self->CheckInitIncluded($n_e_c);	    
  	    last if !$valid;
			}

      if (defined($n_e_p)){
				$w_cnclx = $self->CompareResults($n_e_p, $n_e_c);
        print "Conclusion: $w_cnclx\n" if $verb > 2;
				print "----------------------------------------------------------------------\n" if $verb > 2;
				if ($w_cnclx eq "NONE") {
					$n_e_p = $n_e_c;
				} else {
					last;
				}
			} else {
				$n_e_p = $n_e_c;
			}

		} # end for while(1), the strongest fixed point is found 

		$k = $self->getNextK if !$valid;
  } while ($k <= $K && !($w_cnclx eq "FIXED-POINT"));
	print STDOUT "\n";

  select($old_file) if $verb > 2;
  close LOG if $verb > 2;

	my $win = $winner eq "mod" ? "Controller" : "Environment";
  if ($valid && $w_cnclx eq "FIXED-POINT") {
 		print "The $win is REALIZABLE : With k = $k, after $n_e EPre and $n_a APre. \n" ;

		my @a_tmp = %$n_e_c;
		$$self{ra_fix_e} = $a_tmp[1];
		my $n_size_e = @{$$self{ra_fix_e}};

		@a_tmp = %$n_a_c;
		$$self{ra_fix_a} = $a_tmp[1];
		my $n_size_a = @{$$self{ra_fix_a}};

		print "The size of EPre is $n_size_e, and that of APre is $n_size_a.\n";
		print "The maximal size of EPre and APre is ($n_maxEpre, $n_maxApre)\n";
  } else {
   	print "The $win may not be REALIZABLE : With k = $K, after $n_e EPre and $n_a APre. \n" ;
		print "The maximal size of EPre and APre is ($n_maxEpre, $n_maxApre)\n";
		return 0;
	}

  return 1;
}

sub CompareResults {
  my ($self, $r_l1, $r_l2) = @_;
  my %h_l2 = %$r_l2;
  my @a_l2 = %h_l2;
  return "EMPTYCURRENT" if @a_l2 == 0;

  my %h_l1 = %$r_l1;
  my @a_l1 = %h_l1;
  return "NONE" if (@a_l1 != @a_l2);  

  my ($s1, $s2) = (0, 0);
  my ($ra_fs1, $ra_fs2) = (undef, undef); 

  while (($s1, $ra_fs1) = each(%h_l1)) {
		return "NONE" if ( !exists($h_l2{$s1}) );
		return "NONE" if ( !$self->SameFS($ra_fs1, $h_l2{$s1}) );    
	}

  return "FIXED-POINT";
}

######################################################################
# Calculate the AntiChains of the existential predecessors
######################################################################
sub APre {
  my ($self, $r_L) = @_;
  my $verb = $$self{verbose};
	my @alpha_str = @{ $$self{alpha_str_a} };
  my %L_c = ();

	my %h_L_p = %$r_L;
  my ($j, $ra_fs, $ra_fsC) = (undef, undef, undef); 
  for (my $n_sig = 0; $n_sig < @alpha_str; $n_sig++) {
		my $str = $alpha_str[$n_sig];

    my $ra_fs_p;
	  while (($j, $ra_fs_p) = each(%h_L_p)) {
				$ra_fs = $self->CalculatePreH("a_play", $n_sig, $str, $ra_fs_p);

      if ($verb > 3) {
				print "H for APre with alphabet $str: ";
      	my @a_fs = @$ra_fs;   
	      for (my $k = 0; $k < @a_fs; $k++){
        	print "(";
  	      Utils::print_array($a_fs[$k]);
        	print ") ";
				}
	      print "\n\n";
			}

      if (!defined($ra_fsC)) { 
      	$ra_fsC = $ra_fs;
			} else {
        $ra_fsC = $self->MaxofIntersection($ra_fsC, $ra_fs);
			} 
    }
  }

	$L_c{"dont_care"} = $ra_fsC ; 	
  return \%L_c;
}

######################################################################
# 
######################################################################
sub EPre {
  my ($self, $r_L) = @_;
  my $verb = $$self{verbose};
	my @alpha_str = @{ $$self{alpha_str_e} };

  my %L_c = ();
	my %h_L_p = %$r_L;
  my ($j, $ra_fs, $ra_fsC) = (undef, undef, undef); 
  for (my $n_sig = 0; $n_sig < @alpha_str; $n_sig++) {
		my $str = $alpha_str[$n_sig];

    my $ra_fs_p;
	  while (($j, $ra_fs_p) = each(%h_L_p)) {
			$ra_fs = $self->CalculatePreH("e_play", $n_sig, $str, $ra_fs_p);

			# the following lines for debuging
			if ($verb > 3)  {
				my @a_hs = @$ra_fs;   
				print "H for EPre with output alphabet $str: ";
	     	for (my $k = 0; $k < @a_hs; $k++){
        	print "(";
					Utils::print_array($a_hs[$k]);
        	print ") ";
				}
					print "\n\n";
			} # end of debug codes
  
      if (defined($ra_fsC)) { 
      	$ra_fsC = $self->MaxofUnion($ra_fsC, $ra_fs);
			} else {
        $ra_fsC = $ra_fs;
			} 
    }
  }

  $L_c{"dont_care"} = $ra_fsC;
  return \%L_c;
} 

sub MaxofIntersection {
	my ($self, $r_fs1, $r_fs2) = @_;
  my $r_f_tmp;
  my @a_f_tmp = () ;
  for (my $i = 0; $i < @$r_fs1; $i++){
		for (my $j =0; $j < @$r_fs2; $j++){
			$r_f_tmp = $self->UnionF($$r_fs1[$i], $$r_fs2[$j]);

			push(@a_f_tmp, $r_f_tmp);
		}
	}

  return $self->AntiChainMax(\@a_f_tmp); 
}

sub UnionF {
	my ($self, $r_f1, $r_f2) = @_;

  my @retVal = ();
  for (my $i = 0; $i < @$r_f1; $i++){	
		if ($$r_f1[$i] > $$r_f2[$i]){
			push(@retVal, $$r_f2[$i]);
		} else {
			push(@retVal, $$r_f1[$i]);
		}
	}

	return \@retVal;
}

sub print_L {
  my ($self, $title, $s_player, $r_L) = @_;

  print $title;

  my %h_state = $s_player =~ /e_play/ ? %{$$self{gfga_q_e}} : %{$$self{gfga_q_a}}; 
  my @a_sts = sort( keys( %h_state) ) ;
  for (my $i = 0; $i < @a_sts; $i++) {
		print " $a_sts[$i] ";
  }
  print "\n";

  my $n_s;
  my $ra_fs;
  my $str_s;
  my %h_L = %$r_L;
  while (($str_s, $ra_fs) = each( %h_L)){
    print " $str_s : ";
    $self->print_fs($ra_fs); 
 		print "\n";
	}

	print "\n";
  return 1; 
}

sub print_fs {
	my ($self, $ra_fs) = @_;
  for (my $i = 0 ; $i < @$ra_fs; $i++) {
    print "( ";
		Utils::print_array($$ra_fs[$i]); 
    print " ) ";
	}
}
 
######################################################################
# Compare two rank functions
# return GT if f1 > f2
# return EQ if f1 == f2
# return LT if f1 < f2
# otherwise return UnComparable
######################################################################
sub CompareF {
	my ($self, $r_f1, $r_f2) = @_;
  
  my $b_pre = @$r_f1[0] > @$r_f2[0] ? "GT" :
              @$r_f1[0] == @$r_f2[0] ? "EQ" :
              "LT";

  my $b_this; 
  for (my $i = 1; $i < @$r_f1; $i++){
		$b_this = @$r_f1[$i] > @$r_f2[$i] ? "GT" :
              @$r_f1[$i] == @$r_f2[$i] ? "EQ" :
              "LT";
    if ($b_pre eq $b_this) {
			next;
    }
   
    if ($b_pre eq "GT" && $b_this eq "LT"){
      return "UnComparable";
    } elsif ($b_pre eq "EQ" && !($b_this eq "EQ") ) {
			$b_pre = $b_this;
		} elsif ($b_pre eq "LT" && $b_this eq "GT") {
      return "UnComparable";
		}
	}  

  return $b_pre;        
}

sub SameFS {
  my ($self, $r_fs1, $r_fs2) = @_;
  my @fs_1 = @$r_fs1;
  my @fs_2 = @$r_fs2;
  my $n_fs_1 = @fs_1;
  my $n_fs_2 = @fs_2;
  return 0 if $n_fs_1 != $n_fs_2;   

  my %with_same = ();
  foreach my $f_2 (@fs_2) {
		$with_same{$f_2} = 0;
  }

  my $find_same;
  foreach my $f_1 (@fs_1) {
    $find_same = "";
		foreach my $f_2 (@fs_2) {
			next if $with_same{$f_2};
      $find_same = $self->CompareF($f_1, $f_2);
      if ($find_same eq "EQ") {
				$with_same{$f_2} = 1;
				last;
			}
		}
	
		return 0 if !($find_same eq "EQ");
  }
  return 1;
}

sub MaxofUnion { 
	my ($self, $ra_h1, $ra_h2) = @_;
  my @a_1 = (); 
  for (my $i = 0; $i < @$ra_h1; $i++) {
		$a_1[$i] = 1;
	}

  my @a_2 = (); 
  for (my $i = 0; $i < @$ra_h2; $i++) {
		$a_2[$i] = 1;
	}

  my $ret = undef;
  for (my $j = 0; $j < @$ra_h2; $j++) {
		next if $a_2[$j] == -1;
		for (my $i = 0; $i < @$ra_h1; $i++)	{
			next if $a_1[$i] == -1;
      
      $ret = $self->CompareF($$ra_h1[$i], $$ra_h2[$j]);
			if ($ret =~ /GT/ || $ret =~ /EQ/){
				$a_2[$j] = -1;
				last;   
			} elsif ($ret =~ /LT/) {
        $a_1[$i] = -1;
      } 
		} # end for $i
  } #end for $j

  my @retVal = ();
  for (my $i = 0; $i < @$ra_h1; $i++){
  	push(@retVal, $$ra_h1[$i]) if $a_1[$i] != -1; 
  }

  for (my $i = 0; $i < @$ra_h2; $i++){
  	push(@retVal, $$ra_h2[$i]) if $a_2[$i] != -1; 
  }

  return \@retVal; 
} 

sub AntiChainMax {
	my ($self, $ra_h) = @_;

  my @a_h = (); 
  for (my $i = 0; $i < @$ra_h; $i++) {
		$a_h[$i] = 1;
	}
	
	my $ret = undef;
  for (my $i = 0; $i < @a_h; $i++) {
    next unless ($a_h[$i] != -1);
		my $r_f1 = $$ra_h[$i];
		for (my $j = $i +1 ; ($a_h[$i] != -1) && ($j < @a_h); $j++) {
			next unless ($a_h[$j] != -1);
				
      $ret = $self->CompareF($r_f1, $$ra_h[$j]);
			if ($ret =~ /GT/ || $ret =~ /EQ/){
				$a_h[$j] = -1;
			} elsif ($ret =~ /LT/) {
        $a_h[$i] = -1;
      } 
 		} # end for $j
	} # end for $i
  
  my @retVal = ();
  for (my $i = 0; $i < @a_h; $i++){
    next unless $a_h[$i] != -1;

    push(@retVal, $$ra_h[$i])
  }
  
	return \@retVal;
}

######################################################################
# Calculate the AntiChains of the existential predecessors
######################################################################
sub CalculatePreH {
  my ($self, $s_player, $n_sig, $str_sig, $ra_fs_p) = @_;
  
  my $r_gfga_src = $s_player =~ /e_play/ ? $$self{gfga_q_e} : $$self{gfga_q_a};
	my @a_src = sort (keys( %$r_gfga_src));

	my $r_gfga_tgt = $s_player =~ /e_play/ ? $$self{gfga_q_a} : $$self{gfga_q_e};
	my @a_tgt = sort (keys( %$r_gfga_tgt));

	my %h_trans = %{$$self{gfga_trans}};
  my %finite = %{$$self{gfga_finSt}};
	my %state_tgts = %{$$self{state_tgts}};
	my %ary = %{$$self{ary}};
	
	my @a_fs_p = @$ra_fs_p;
  my $crtK = $self->getCurrentK;

  my @a_nu_L = ();
	my $ra_nu_L = \@a_nu_L;
  my $verbose = $$self{verbose};

  my ($ra_f, $n_tmp) = (undef, undef);
  foreach $ra_f (@a_fs_p) {
    my @a_f = @{$ra_f};

    my @a_h = ();
    for (my $qi = 0; $qi < @a_src; $qi++) {
      my $q = $a_src[$qi];
      my $fq = defined($finite{$q}) ?  ($crtK == 0 ? -1 : $crtK) : $crtK; 

			my $r_tgts = $state_tgts{$q};
			next if !defined $r_tgts;		
			my %tgts = %$r_tgts;
			my ($qp, $dc) = (undef, undef);	
			while (($qp, $dc) = each (%tgts)) {	
				my $qj = $ary{$qp};
				my $tr_exists	= $h_trans{$q.":".$n_sig.":".$qp};
        next if !defined $tr_exists;

        if ($a_f[$qj] == -1){
        	$fq = -1;
	        print "$q--$str_sig-->$qp : $fq\n" if $verbose > 3; 
          last;
        }
        if (defined($finite{$qp})) {
        	 $n_tmp = $a_f[$qj] - 1;
        } else {
        		$n_tmp = $a_f[$qj];
        }
        $fq = $n_tmp if ($fq > $n_tmp);
	      print "$q--$str_sig-->$qp : $fq\n" if $verbose > 3; 
			} # end for $qj, h($qj) is evaluated.

			if (defined($finite{$q}) && $fq == 0) {				$fq = -1;
			} 
      print "f($q)=$fq\n\n" if $verbose > 3;
			push(@a_h, $fq);	
		} # end for $qi, now we have a new rank function.

		push(@{$ra_nu_L}, \@a_h); 
  } # end for @ra_f


	return $self->AntiChainMax($ra_nu_L);
}

sub CheckInitIncluded {
	my ($self, $rh_fs) = @_;
  my %h_fs = %$rh_fs;
	my @a_fs = %h_fs;
	return 0 if @a_fs < 1;

	my ($dont_care, $ra_fs, $key, $min) = (undef, undef, undef, undef);
	while (($dont_care, $ra_fs) = each(%h_fs)) {
		my @ara_fs = @$ra_fs;
		my $ValidThis = 0; 
		for (my $i = 0; $i < @ara_fs; $i++) {
			my @crt_f = @{$ara_fs[$i]};
		 	my %h_idx = %{ $$self{gfga_index_init} };
			while (($key, $min) = each(%h_idx)){
			  if ($crt_f[$key] >= $min){
			  	$ValidThis = 1;
			  	last;
			  }
			}
    }
		return 0 if !$ValidThis;
	}

	return 1;
}

######################################################################
# To check whether (s, s') is a legal game turn.
# Now, in our case, it always return 1
######################################################################
sub gameTurn {
  return 1;
}

######################################################################
# Return the maximal length of the search w.r.t the sizes of the UCW  
# and the Game
######################################################################
sub getMaxK {
  my $self = shift;
	return $$self{maxK};
}

sub getNextK {
  my $self = shift;
  $$self{n_crnt_K} ++;
	return $$self{n_crnt_K} ;
}

sub getCurrentK {
  my $self = shift;
	return $$self{n_crnt_K};
}

######################################################################
# Strategy Construction from AntiChains
######################################################################
sub StrategyConstruction {
	my $self = shift;
	my $debugdir = $$self{directory};
	my $winner = $$self{winner};

	my %new_hash3 = ();   
	$$self{fix_bigraph} = \%new_hash3;

	my %new_hash4 = ();   
	$$self{bg_nodes} = \%new_hash4;

	$self->PostFix;
	$self->BuildBiGraph;
	$self->BuildOutputFunction;

	my $str;
	if ($winner eq "mod") {	
		$self->CreateTransTableMoore;
		$str = $self->MooreMachineToVerilog;
	} else {
		$self->CreateTransTableMealy;
		$str = $self->MealyMachineToVerilog;
	}

 	open(LOG, ">$$self{directory}alres.v");
	print LOG $str;
	close(LOG);  

	return 1;
}

sub PostFix {
	my $self = shift;
	my $winner = $$self{winner};
	
	if ($winner eq "env") {
		$$self{ra_post_fix_a} = $$self{ra_fix_a};
		$$self{ra_post_fix_e} = $$self{ra_fix_e};
  	return;
	}

	my %q_s = %{$$self{gfga_q_e}};
	my @a_q_s = sort keys %q_s;

  my %inits = %{ $$self{gfga_inits} };
  my %finSt = %{ $$self{gfga_finSt} };
  my $verb = $$self{verbose};

  open(LOG, ">$$self{directory}post.log") if $verb > 2;  
  my $old_file = select(LOG) if $verb > 2;

	my @f_0 = ();
	for (my $i = 0; $i < @a_q_s; $i++ ){
		my $q = $a_q_s[$i];
		if (defined $inits{$q}) {
			if (defined $finSt{$q}) {
				push(@f_0, 1);
			} else {
				push(@f_0, 0);			
			}
		} else {
			push(@f_0, -1);
		}
	}

	if ($verb > 2) {
		Utils::print_array(\@f_0);
		print "\n";
	}

	my @L = ();
	push(@L, \@f_0);
	my ($rar_e_crt, $rar_e_p, $rar_a_crt, $rar_a_p) = (undef, undef, undef, undef);
 
	# Eihter of the following two lines can be used. From $rar_e_p = \@L, we can see the evolution 
  # of the Post from F_0. 
	$rar_e_p = $$self{ra_fix_e};
#	$rar_e_p = \@L;	

	my $fixPoint = 0;
	while (!$fixPoint){
		$rar_a_crt = $self->CalculatePostFix("e_play", $rar_e_p);
		if (defined $rar_a_p) {
			print "retValue undefined\n" if (!defined $rar_a_crt);
			$fixPoint = $self->SameFS($rar_a_p, $rar_a_crt);
			$rar_a_p = $rar_a_crt;
		} else {
			$rar_a_p = $rar_a_crt;
		}

		if ($verb > 2) {
			print "--Current A---------------------------------------------------------------------\n"; 
			my @a_p = @$rar_a_p;
			for (my $i = 0; $i < @a_p; $i++){
				Utils::print_array( $a_p[$i]);
				print "\n";
			}
		}
		last if $fixPoint;

		$rar_e_crt = $self->CalculatePostFix("a_play", $rar_a_p);
		$rar_e_crt = $self->MaxofUnion($rar_e_crt, $rar_e_p) if defined $rar_e_p;
		if (defined $rar_e_p) {
			$fixPoint = $self->SameFS($rar_e_p, $rar_e_crt);
			$rar_e_p = $rar_e_crt;
		} else {
			$rar_e_p = $rar_e_crt;
		}

		if ($verb > 2) {
			print "--Current E---------------------------------------------------------------------\n";
			my @e_p = @$rar_e_p;
			for (my $i = 0; $i < @e_p; $i++){
				Utils::print_array( $e_p[$i]);
				print "\n";
			}
		}
	}

  close(LOG) if $verb > 2;  
	select($old_file) if $verb > 2;

	$$self{ra_post_fix_a} = $rar_a_p;
	$$self{ra_post_fix_e} = $rar_e_p;
	return 1;
}

sub BuildBiGraph {
	my $self = shift;
	
	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my $ra_post_fix_e	= $$self{ra_post_fix_e};
	my @a_post_fix_a = @$ra_post_fix_a;
	my @a_post_fix_e = @$ra_post_fix_e;

	my $bg_nodes = $$self{bg_nodes};
	foreach my $crt_f (@a_post_fix_e) {
		my $nu_node = $self->NextState;
		$$bg_nodes{$crt_f} = $nu_node;
		$$bg_nodes{$nu_node} = $crt_f;
	}

	foreach my $crt_f (@a_post_fix_a) {
		my $nu_node = $self->NextState;
		$$bg_nodes{$crt_f} = $nu_node;
		$$bg_nodes{$nu_node} = $crt_f;
	}

	my @nodes = keys %$bg_nodes;
	my %h_s = %{$$self{r_e}};
	my @a_s = sort keys %h_s;
	my $n_alphabets = 2**@a_s;

	foreach my $crt_f (@a_post_fix_e) {
		my @a_crt = ();
		push(@a_crt, $crt_f);

		for (my $i = 0; $i < $n_alphabets; $i++) {
			my $post = $self->CalculatePost("e_play", \@a_crt, $i);
			$post = $self->RemoveUnSubsumed("e_play", $post);

			if (@$post != 0) {
				foreach my $a_fix (@a_post_fix_a) {
					my $subsumed = $self->CompareF($a_fix, $$post[0]);
					$self->PutToBiGraph($crt_f, $i, $a_fix) if ($subsumed eq "GT" or $subsumed eq "EQ");
				}
			}
		} # end for enumerating n_alphabets
	} # end for enumerating existential fixpoints

	if ($$self{verbose} > 2) {
		my $str = $self->PrintBiGraph("BiGraph_0");
		my $debugdir = $$self{directory};
  	open(LOG, ">$$self{directory}bi_0.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."bi_0.dot");
	}

	return 1;
}

sub PrintBiGraph {
	my ($self, $graphname) = @_;
	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my $ra_post_fix_e	= $$self{ra_post_fix_e};
	my @a_post_fix_a = @$ra_post_fix_a;
	my @a_post_fix_e = @$ra_post_fix_e;

	my $bg_nodes = $$self{bg_nodes};
	my $ra_e_alpha = $$self{fix_bigraph};
	my @alpha_str_e	= @{ $$self{alpha_str_e} };

	my $string = qq!digraph "$graphname" {\n!;
  $string .= qq!size = \"11,7.5\";\ncenter = true;\nrotate = 90;\n!;
  $string .= qq!"title" [label=\"$graphname\",shape=plaintext];\n!;

  my $shape = "ellipse";
	foreach my $crt_f (@a_post_fix_a) {
		my $nodeLabel = $$bg_nodes{$crt_f};
		my $nodeName = join("_", @$crt_f, $nodeLabel);
	  $string .= qq!"$nodeName" [label="$nodeLabel", shape=$shape]\n!;
	}

  $shape = "box";
	foreach my $crt_f (@a_post_fix_e) {
		my $nodeLabel = $$bg_nodes{$crt_f};
		my $nodeName = join("_", @$crt_f, $nodeLabel);
	  $string .= qq!"$nodeName" [label="$nodeLabel", shape=$shape]\n!;
	}
 
	foreach my $src_f (@a_post_fix_e) {
		my $srcLabel = $$bg_nodes{$src_f};
		my $srcName = join("_", @$src_f, $srcLabel);

		my %trans = %{ $$ra_e_alpha{$srcLabel} };
		my ($link, $status_ok) = (undef, undef);
		while ( ($link, $status_ok) = each(%trans) ) {
			next if !$status_ok;

			my ($alpha, $dstLabel) = split(":", $link);
			my $alpha_str = $alpha_str_e[$alpha];
			my $dstName = join("_", @{ $$bg_nodes{$dstLabel} }, $dstLabel);
      $string .= qq!"$srcName" -> "$dstName" [label="{$alpha_str}"]\n!;
		}
	}

	$string .= qq!}\n!;
	return $string;
}

sub BuildOutputFunction {
	my $self = shift;
	my $winner = $$self{winner};

	$self->RemoveRedundantLink;
	$self->RemoveUnNecessaryStates;
	$self->DuplicateStates if $winner eq "mod";

	return 1;
}

sub RemoveRedundantLink {
	my $self = shift;

	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my @a_post_fix_a = @$ra_post_fix_a;

	my $bg_nodes = $$self{bg_nodes};
	my $rh_bi_graph = $$self{fix_bigraph};
	
	foreach my $crt_f_a (@a_post_fix_a) {
		my $src = $$bg_nodes{$crt_f_a};

		my $rh_from_a = $$rh_bi_graph{$src};
		next if !defined $rh_from_a;
		my %h_from_a = %$rh_from_a;
		my $src_in_cnt = 0;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			$src_in_cnt ++ if $valid; 
		} 
		next if $src_in_cnt <= 1;

		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			my ($alpha, $dst) = split(":", $trans);
			my $rh_from_e = $$rh_bi_graph{$dst};
			my %h_from_e = %$rh_from_e;
			my ($dst_out_cnt, $valid_out_this) = (0, 0);
			my ($out_trans, $valid_o) = (undef, undef);
			while (($out_trans, $valid_o) = each(%h_from_e)) {
				next if !$valid_o;
				$dst_out_cnt ++;
				my ($alpha_o, $src_e) = split(":", $out_trans);
				$valid_out_this = 1 if ($alpha == $alpha_o && $src eq $src_e); 
			}			
			next if $dst_out_cnt <= 1;

			if ($valid_out_this) {
				$$rh_from_a{$trans} = 0;
				$$rh_from_e{"$alpha:$src"} = 0;
				$src_in_cnt --;
			}
			last if $src_in_cnt == 1;
		} 
	}

	if ($$self{verbose} > 2) {
		my $str = $self->PrintBiGraph("After RemoveRedundantLink");
		my $debugdir = $$self{directory};
  	open(LOG, ">$$self{directory}bi_1.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."bi_1.dot");
	}
	return 1;
}

sub RemoveUnNecessaryStates {
	my $self = shift;

	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my @a_post_fix_a = @$ra_post_fix_a;

	my $bg_nodes = $$self{bg_nodes};
	my $rh_bi_graph = $$self{fix_bigraph};

	foreach my $crt_f_a (@a_post_fix_a) {
		my $src = $$bg_nodes{$crt_f_a};

		my $rh_from_a = $$rh_bi_graph{$src};
		next if !defined $rh_from_a;
		my %h_from_a = %$rh_from_a;
		my $src_in_cnt = 0;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			$src_in_cnt ++ if $valid; 
		} 
		next if $src_in_cnt != 1;

		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			my ($alpha, $dst) = split(":", $trans);
			my $rh_from_e = $$rh_bi_graph{$dst};
			my %h_from_e = %$rh_from_e;
			my ($dst_out_cnt, $valid_out_this) = (0, 0);
			my ($out_trans, $valid_o) = (undef, undef);
			while (($out_trans, $valid_o) = each(%h_from_e)) {
				next if !$valid_o;
				$dst_out_cnt ++;
			}			
			next if $dst_out_cnt <= 1;

			$$rh_from_a{$trans} = 0;
			$$rh_from_e{"$alpha:$src"} = 0;
		} 
	}

	if ($$self{verbose} > 2) {
		my $str = $self->PrintBiGraph("After RemoveUnNecessaryStates");
		my $debugdir = $$self{directory};
  	open(LOG, ">$$self{directory}bi_2.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."bi_2.dot");
	}

}

sub DuplicateStates {
	my $self = shift;
	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my @a_post_fix_a = @$ra_post_fix_a;

	my $bg_nodes = $$self{bg_nodes};
	my $rh_bi_graph = $$self{fix_bigraph};

	my @nu_nodes = ();		
	my %h_to_update = ();
	foreach my $crt_f_a (@a_post_fix_a) {
		my $src = $$bg_nodes{$crt_f_a};

		my $rh_from_a = $$rh_bi_graph{$src};
		next if !defined $rh_from_a;
		my %h_from_a = %$rh_from_a;
		my $src_in_cnt = 0;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			$src_in_cnt ++ if $valid; 
		} 
		next if $src_in_cnt <= 1;

		my %in_alphas = ();
		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			my ($alpha, $dst) = split(":", $trans);
			$in_alphas{$alpha} = 1;
		} 
		
		my @a_in_alphas = sort keys %in_alphas;
		next if @a_in_alphas == 1;

		for (my $i = 0; $i < @a_in_alphas - 1; $i++) {
			my $crt_alpha = $a_in_alphas[$i];
			my @new_f = @$crt_f_a;
			my $nu_node = $self->NextState;
			$$bg_nodes{\@new_f} = $nu_node;
			$$bg_nodes{$nu_node} = \@new_f;
			push(@nu_nodes, \@new_f);
			
			while ( ($trans, $valid) = each(%h_from_a)) {
				next if !$valid; 
				my ($alpha, $dst) = split(":", $trans);
				next if $alpha ne $crt_alpha;
				
				$$rh_from_a{$alpha.":".$dst} = 0;
				my $r_e = $$bg_nodes{$dst};
				$h_to_update{"$dst:$alpha:$src"} = $nu_node;
			}
		}
 	}

	for (my $i = 0; $i < @nu_nodes; $i++) {
		push(@{$ra_post_fix_a}, $nu_nodes[$i]);
	}

	my ($e_keys, $nu_node) = (undef, undef);
	while (($e_keys, $nu_node) = each(%h_to_update) ){
		my ($e_node, $alpha, $a_node) = split(":", $e_keys); 
		my $rh_from_e = $$rh_bi_graph{$e_node};
		$$rh_from_e{$alpha.":".$a_node} = 0;
		my ($r_e, $r_nu) = ($$bg_nodes{$e_node}, $$bg_nodes{$nu_node});
		$self->PutToBiGraph($r_e, $alpha, $r_nu);
	}

	if ($$self{verbose} > 2) {
		my $str = $self->PrintBiGraph("After DuplicateStates");
		my $debugdir = $$self{directory};
  	open(LOG, ">$$self{directory}bi_3.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."bi_3.dot");
	}
}

sub CreateTransTableMealy {
	my $self = shift;
	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my @a_post_fix_a = @$ra_post_fix_a;
	my $ra_post_fix_e	= $$self{ra_post_fix_e};
	my @a_post_fix_e = @$ra_post_fix_e;

	my $rh_bi_graph = $$self{fix_bigraph};
	my $bg_nodes = $$self{bg_nodes};

	# rebuild the bigraph by removing invalid transitions. 
	my %bi_a = ();
	foreach my $crt_f_a (@a_post_fix_a) {
		my $src = $$bg_nodes{$crt_f_a};
		my $rh_from_a = $$rh_bi_graph{$src};
		if (!defined $rh_from_a) {
			$bi_a{$src} = 1;
			next;
		}
		my %h_from_a = %$rh_from_a;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			$bi_a{$src} = 1;
			last;
		} 
	}

	my %bi_e = ();
	foreach my $crt_f_e (@a_post_fix_e) {
		my $src = $$bg_nodes{$crt_f_e};

		my $rh_from_a = $$rh_bi_graph{$src};
		next if !defined $rh_from_a;
		my %h_from_a = %$rh_from_a;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			$bi_e{$src} = $trans;
			last;
		} 
	}

	my %h_sigs = %{ $$self{r_a} };	
	my @a_sigs = sort keys %h_sigs;
	my $n_alpha = 2**@a_sigs;

	my %h_mealy_trans = ();
	my ($src_a, $dc) = (undef, undef);
	while (($src_a, $dc) = each(%bi_a)) {
		my $crt_f_a = $$bg_nodes{$src_a};

		my @a_crt = ();
		push(@a_crt, $crt_f_a);
		my @nu_trans_table = (); 
		for (my $i = 0; $i < $n_alpha; $i++) {
			my $post = $self->CalculatePost("a_play", \@a_crt, $i);
			my $r_f = $$post[0];

			my $trans = undef;
			foreach my $r_e_f (@a_post_fix_e) {
				my $compResult = $self->CompareF($r_e_f, $r_f);
				next if $compResult eq "LT" or $compResult eq "UnComparable";	

				my $dst_e = $$bg_nodes{$r_e_f};
				$trans = $bi_e{$dst_e};
				last;
			}

			$h_mealy_trans{$src_a.":".$i} = $trans;
		}
	}

	# looking for the inital state
	my %q_as = %{$$self{gfga_q_a}};
	my @a_q_as = sort keys %q_as;
	my %inits = %{ $$self{gfga_inits} };
  my %finSt = %{ $$self{gfga_finSt} };
	my @f_0 = ();
	foreach my $q (@a_q_as){
		if (defined $inits{$q}) {
			if (defined $finSt{$q}) {
				push(@f_0, 1);
			} else {
				push(@f_0, 0);			
			}
		} else {
			push(@f_0, -1);
		}
	}

	my $init_st = undef;
	foreach my $crt_f_a (@a_post_fix_a) {
		my $compResult = $self->CompareF($crt_f_a, \@f_0);
		next if $compResult eq "LT" or $compResult eq "UnComparable";	
		my $src = $$bg_nodes{$crt_f_a};

#		print "init st : $src\n";
		$init_st = $src;
		last;
	}

	# to exclude those unreachable from the init
	my %reachable = ();
	$reachable{$init_st} = 1;
	my $fixed = 0;
	my %new_reaches = %reachable;
	while(1) {
		my @reach_p = sort keys %new_reaches;
		last if @reach_p == 0;

		%new_reaches = ();
		foreach my $src_tmp (@reach_p) {
			for (my $i = 0; $i < $n_alpha; $i++) {
				my $trans = $h_mealy_trans{$src_tmp.":".$i} ;
				next if !defined $trans;
				my ($out, $x_st) = split(":", $trans);
				if (!defined $reachable{$x_st}) {
					$new_reaches{$x_st} = 1;
					$reachable{$x_st} = 1; 
				}
			}	
		}
	} 

	my @all_as = sort keys %bi_a;
	foreach my $node (@all_as) {
		if (!defined $reachable{$node}) {
#			print $node." is unreachable \n";
			$bi_a{$node} = -1;
		}
	}

	$$self{s_mealy_init} = $init_st;
	$$self{h_mealy_st} = \%bi_a;
	$$self{h_mealy_trans} = \%h_mealy_trans;

	if ($$self{verbose} > 2) {
		my $str = $self->MealyMachineToDot("Mealy Machine");
		my $debugdir = $$self{directory};
	 	open(LOG, ">$$self{directory}mealy.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."mealy.dot");
	}

	return;
}

sub MealyMachineToDot {
	my ($self, $graphname) = @_;

	my $init = 	$$self{s_mealy_init};
	return "Wrong ! " if !defined $init;
	my %h_mealy_st = %{ $$self{h_mealy_st} };
	my %h_mealy_trans = %{ $$self{h_mealy_trans} };

	my @alpha_str_a	= @{ $$self{alpha_str_a} };
	my @alpha_str_e	= @{ $$self{alpha_str_e} };

	my $string = qq!digraph "$graphname" {\n!;
  $string .= qq!size = \"11,7.5\";\ncenter = true;\nrotate = 90;\n!;
  $string .= qq!"title" [label=\"$graphname\",shape=plaintext];\n!;

	my ($st, $valid, $src_in, $out_dst, $in, $out, $dst) = (undef, undef, undef, undef, undef, undef, undef);
	while ( ($st, $valid) = each (%h_mealy_st) ) {
		next if $valid == -1;	
	  $string .= qq!"$st" [label=\"$st\", shape="ellipse"]\n!;
	}

	$string .= qq!"init_$init" [style=invis]\n!;
	$string .= qq!"init_$init" -> "$init"\n!;

	while (($src_in, $out_dst) = each (%h_mealy_trans)) {
		($st, $in) = split(":", $src_in);
		next if $h_mealy_st{$st} == -1;

		($out, $dst) = split(":", $out_dst);
		my $in_str = $alpha_str_a[$in];
		my $out_str = $alpha_str_e[$out];
	  $string .= qq!"$st" -> "$dst" [label="{$in_str / $out_str}"]\n!;
	}

	$string .= qq!}\n!;
	return $string;
}

sub MealyMachineToVerilog {
	my $self = shift;

	my $init = 	$$self{s_mealy_init};
	return "Wrong ! " if !defined $init;
	my %h_mealy_st = %{ $$self{h_mealy_st} };
	my %h_mealy_trans = %{ $$self{h_mealy_trans} };

	my @alpha_str_a	= @{ $$self{alpha_str_a} };
	my @alpha_str_e	= @{ $$self{alpha_str_e} };

	# decide the number of bits for encoding the states
	my $st_cnt = 0;
	my ($st, $valid) = (undef, undef);
	while ( ($st, $valid) = each (%h_mealy_st) ) {
		next if $valid == -1;	
		$st_cnt++;
	}

	my $bit_cnt = 1;
	my $range = 2;
	while ($range < $st_cnt) {
		$bit_cnt++;
		$range = $range << 1;
	}

	# encoding the states
	my %h_st_map = ();
	my $cnt_st = 0;
	while ( ($st, $valid) = each (%h_mealy_st) ) {
		next if $valid == -1;	
		$h_st_map{$st} = $cnt_st;
		$cnt_st++;
	}

	# preparing the output function
	my %output_comb = ();	
	my @trans_keys = sort keys %h_mealy_trans;
	my $crt_st = "____";
	my $first_st = 1;
	foreach my $tr_key (@trans_keys) {
		my ($st, $n_inalpha) = split(":", $tr_key);
		next if $h_mealy_st{$st} == -1;	

		my $st_code = $h_st_map{$st};
		my $alpha_in = $alpha_str_a[$n_inalpha];
		my @sigs_in = split("_", $alpha_in);
		my $alpha_in_str = join(" && ", @sigs_in);
 
		my ($out, $dst) = split(":", $h_mealy_trans{$tr_key});
		my $alpha_out = $alpha_str_e[$out];
		my @sigs_out = split("_", $alpha_out);
		foreach my $sig (@sigs_out) {
			next if $sig =~ /!/ ;
			my $st_pred = $output_comb{$sig};
			if (!defined $st_pred) {
				my %h_nu = ();
				$st_pred = \%h_nu;
				$output_comb{$sig} = $st_pred;
			}
			$$st_pred{ "(state == $st_code) && $alpha_in_str" } = 1;
		}
	}

	# the module declaration
	my $string = qq!module alres (!;
	$string .= qq!clk!;

	my %h_as = %{$$self{r_a}};
	my @a_s = sort keys %h_as;
	foreach my $sig (@a_s) {
		$string .= qq!, $sig!;
	} 

	my %h_s = %{$$self{r_e}};
	my @e_s = sort keys %h_s;
	foreach my $sig (@e_s) {
		$string .= qq!, $sig!;
	} 
	$string .= qq!);\n!;

	# the input/output declaration
	$string .= qq!input clk, $a_s[0]!;
	for (my $i = 1; $i < @a_s; $i++) {
		my $sig = $a_s[$i];
		$string .= qq!, $sig!;
	} 
	$string .= qq!;\n!;

	$string .= qq!output $e_s[0]!;
	for (my $i = 1; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		$string .= qq!, $sig!;
	} 
 	$string .= qq!;\n!;

	# variable declaration
	$string .= qq!wire $e_s[0]!;
	for (my $i = 1; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		$string .= qq!, $sig!;
	} 
 	$string .= qq!;\n!;

	my $bit_cnt_1 = $bit_cnt - 1;
	$string .= qq!reg [$bit_cnt_1:0] state;\n!;		

	# initial values
	$string .= qq!\ninitial state = $h_st_map{$init};\n!;

	#output combinationals
	foreach my $sig (@e_s) {
		my $rh_out_comb = $output_comb{$sig} ;
		if (!defined $rh_out_comb) {
			$string .= qq!\nassign $sig = 0;\n!;
			next;
		}

		$string .= qq!\nassign $sig = (!;
		my %rh_c = %$rh_out_comb;
		my ($cond, $dc) = (undef, undef);
		my $first = 1;
		while (($cond, $dc) = each(%rh_c)) {
			$string .= $first ? "($cond)" : "|| ($cond)" ;
			$first = 0;
		} 
		$string .= qq!);\n!;
	}

	# the state transition table
	$string .= qq!\nalways \@(posedge clk)\n!;
	$string .= qq!\tcase(state)\n!;

	$crt_st = "____";
	$first_st = 1;
	foreach my $tr_key (@trans_keys) {
		my ($st, $n_inalpha) = split(":", $tr_key);
		next if $h_mealy_st{$st} == -1;	

		my $st_code = $h_st_map{$st};
		my $alpha_in = $alpha_str_a[$n_inalpha];
		my @sigs_in = split("_", $alpha_in);
		my $alpha_in_str = join(" && ", @sigs_in);
 
		my ($out, $dst) = split(":", $h_mealy_trans{$tr_key});
		my $n_dst = $h_st_map{$dst};
		if ($crt_st ne $st) {
			$crt_st = $st;	
			$string .= qq!\tend\n! if (!$first_st);
			$string .= qq!\t$st_code : begin\n!; 			
			$first_st = 0;
		} 
		$string .= qq!\t\tif ($alpha_in_str) state = $n_dst;\n!; 
	}

	$string .= qq!\tend\n\tendcase\n\n!;
	$string .= qq!endmodule\n!;

	return $string;
}

sub CreateTransTableMoore {
	my $self = shift;
	my $ra_post_fix_a	= $$self{ra_post_fix_a};
	my @a_post_fix_a = @$ra_post_fix_a;
	my $ra_post_fix_e	= $$self{ra_post_fix_e};
	my @a_post_fix_e = @$ra_post_fix_e;

	my $rh_bi_graph = $$self{fix_bigraph};
	my $bg_nodes = $$self{bg_nodes};

	# rebuild the bigraph by removing invalid transitions. 
	my %bi_a = ();
	foreach my $crt_f_a (@a_post_fix_a) {
		my $src = $$bg_nodes{$crt_f_a};
		my $rh_from_a = $$rh_bi_graph{$src};
		my %h_from_a = %$rh_from_a;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			my ($alpha, $dst) = split(":", $trans);
			$bi_a{$src} = $alpha;
			last;
		} 
	}

	my %bi_e = ();
	foreach my $crt_f_e (@a_post_fix_e) {
		my $src = $$bg_nodes{$crt_f_e};

		my $rh_from_a = $$rh_bi_graph{$src};
		my %h_from_a = %$rh_from_a;
		my ($trans, $valid) = (undef, undef);
		while ( ($trans, $valid) = each(%h_from_a)) {
			next if !$valid; 
			my ($alpha, $dst) = split(":", $trans);
			$bi_e{$src} = $dst;
			last;
		} 
	}

	my %h_sigs = %{ $$self{r_a} };	
	my @a_sigs = sort keys %h_sigs;
	my $n_alpha = 2**@a_sigs;

	my %h_moore_trans = ();
	my ($src_a, $dc) = (undef, undef);
	while (($src_a, $dc) = each(%bi_a)) {
		my $crt_f_a = $$bg_nodes{$src_a};

		my @a_crt = ();
		push(@a_crt, $crt_f_a);
		my @nu_trans_table = (); 
		for (my $i = 0; $i < $n_alpha; $i++) {
			my $post = $self->CalculatePost("a_play", \@a_crt, $i);
			my $r_f = $$post[0];

			my $x_st = undef;
			foreach my $r_e_f (@a_post_fix_e) {
				my $compResult = $self->CompareF($r_e_f, $r_f);
				next if $compResult eq "LT" or $compResult eq "UnComparable";	

				my $dst_e = $$bg_nodes{$r_e_f};
				$x_st = $bi_e{$dst_e};
				last;
			}

			$h_moore_trans{$src_a.":".$i} = $x_st;
		}
	}

	# looking for the inital state
	my %q_es = %{$$self{gfga_q_e}};
	my @a_q_es = sort keys %q_es;
	my %inits = %{ $$self{gfga_inits} };
  my %finSt = %{ $$self{gfga_finSt} };
	my @f_0 = ();
	for (my $i = 0; $i < @a_q_es; $i++ ){
		my $q = $a_q_es[$i];
		if (defined $inits{$q}) {
			if (defined $finSt{$q}) {
				push(@f_0, 1);
			} else {
				push(@f_0, 0);			
			}
		} else {
			push(@f_0, -1);
		}
	}

	my $init_st = undef;
	foreach my $crt_f_e (@a_post_fix_e) {
		my $compResult = $self->CompareF($crt_f_e, \@f_0);
		next if $compResult eq "LT" or $compResult eq "UnComparable";	

		my $src = $$bg_nodes{$crt_f_e};
		$init_st = $bi_e{$src};
		last;
	}

	# to exclude those unreachable from the init
	my %reachable = ();
	$reachable{$init_st} = 1;
	my $fixed = 0;
	my %new_reaches = %reachable;
	while(1) {
		my @reach_p = sort keys %new_reaches;
		last if @reach_p == 0;

		%new_reaches = ();
		foreach my $src_tmp (@reach_p) {
			for (my $i = 0; $i < $n_alpha; $i++) {
				my $x_st = $h_moore_trans{$src_tmp.":".$i} ;
				if (!defined $reachable{$x_st}) {
					$new_reaches{$x_st} = 1;
					$reachable{$x_st} = 1; 

#					print $x_st." is reached\n";
				}
			}	
		}
	} 

	my @all_as = sort keys %bi_a;
	foreach my $node (@all_as) {
		if (!defined $reachable{$node}) {
#			print $node." is unreachable \n";
			$bi_a{$node} = -1;
		}
	}

	$$self{s_moore_init} = $init_st;
	$$self{h_moore_st} = \%bi_a;
	$$self{h_moore_trans} = \%h_moore_trans;

	if ($$self{verbose} > 2) {
		my $str = $self->MooreMachineToDot("Moore Machine");
		my $debugdir = $$self{directory};
	 	open(LOG, ">$$self{directory}moore.dot");
		print LOG $str;
		close(LOG);  
		Utils::dot2ps($debugdir."moore.dot");
	}

	return;
}
 
sub MooreMachineToDot {
	my ($self, $graphname) = @_;

	my %h_moore_st = %{ $$self{h_moore_st} };
	my %h_moore_trans = %{ $$self{h_moore_trans} };
	my @alpha_str_a	= @{ $$self{alpha_str_a} };

	my $init = 	$$self{s_moore_init};
	my $string = qq!digraph "$graphname" {\n!;
  $string .= qq!size = \"11,7.5\";\ncenter = true;\nrotate = 90;\n!;
  $string .= qq!"title" [label=\"$graphname\",shape=plaintext];\n!;

	my ($st, $alpha, $trans, $dst) = (undef, undef, undef, undef);
	while ( ($st, $alpha) = each (%h_moore_st) ) {
		next if $alpha == -1;	
	  $string .= qq!"$st" [label=\"$st\\n($alpha)\", shape="ellipse"]\n!;
	}

	$string .= qq!"init_$init" [style=invis]\n!;
	$string .= qq!"init_$init" -> "$init"\n!;

	while (($trans, $dst) = each (%h_moore_trans)) {
		($st, $alpha) = split(":", $trans);
		next if $h_moore_st{$st} == -1;
		my $alpha_str = $alpha_str_a[$alpha];
	  $string .= qq!"$st" -> "$dst" [label="{$alpha_str}"]\n!;
	}

	$string .= qq!}\n!;
	return $string;
}

sub MooreMachineToVerilog {
	my $self = shift;

	my %h_moore_st = %{ $$self{h_moore_st} };
	my %h_moore_trans = %{ $$self{h_moore_trans} };
	my @alpha_str_a	= @{ $$self{alpha_str_a} };

	# decide the number of bits for encoding the states
	my $init = 	$$self{s_moore_init};
	my $st_cnt = 0;
	my ($st, $alpha) = (undef, undef);
	while ( ($st, $alpha) = each (%h_moore_st) ) {
		next if $alpha == -1;	
		$st_cnt++;
	}

	my $bit_cnt = 1;
	my $range = 2;
	while ($range < $st_cnt) {
		$bit_cnt++;
		$range = $range << 1;
	}

	# encoding the states
	my %h_st_map = ();
	my $cnt_st = 0;
	while ( ($st, $alpha) = each (%h_moore_st) ) {
		next if $alpha == -1;	
		$h_st_map{$st} = $cnt_st;
		$cnt_st++;
	}

	# encoding the output function
	my %h_s = %{$$self{r_e}};
	my @e_s = sort keys %h_s;
	my @bitmap = ();
	for (my $i = 0 ; $i < @e_s; $i++) {
		push(@bitmap, 0);
	}

	my %output_comb = ();	
	my $n_alpha = undef;
	my ($trans, $out) = (undef, undef);
  while (($st, $out) = each (%h_moore_st)) {
		next if $out == -1;

		Utils::int2binary(\@bitmap, $out);
		for (my $i = 0; $i < @bitmap; $i++) {
			next if !$bitmap[$i];

			my $sig = $e_s[$i];
			my $st_pred = $output_comb{$sig};
			if (!defined $st_pred) {
				my %h_nu = ();
				$st_pred = \%h_nu;
				$output_comb{$sig} = $st_pred;
			}
			$$st_pred{ $h_st_map{$st} } = 1;
		}
	}

	# the module declaration
	my $string = qq!module alres (!;
	$string .= qq!clk!;
	my %h_a_s = %{$$self{r_a}};
	my @a_s = sort keys %h_a_s;
	for (my $i = 0; $i < @a_s; $i++) {
		my $sig = $a_s[$i];
		$string .= qq!, $sig!;
	} 

	for (my $i = 0; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		$string .= qq!, $sig!;
	} 
	$string .= qq!);\n!;

	# the input/output declaration
	$string .= qq!input clk, $a_s[0]!;
	for (my $i = 1; $i < @a_s; $i++) {
		my $sig = $a_s[$i];
		$string .= qq!, $sig!;
	} 
	$string .= qq!;\n!;

	$string .= qq!output $e_s[0]!;
	for (my $i = 1; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		$string .= qq!, $sig!;
	} 
 	$string .= qq!;\n!;

	# variable declaration
	$string .= qq!wire $e_s[0]!;
	for (my $i = 1; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		$string .= qq!, $sig!;
	} 
 	$string .= qq!;\n!;

	my $bit_cnt_1 = $bit_cnt - 1;
	$string .= qq!reg [$bit_cnt_1:0] state;\n\n!;		

	my $st_label;
	# combinational logics for the output 
	for (my $i = 0; $i < @e_s; $i++) {
		my $sig = $e_s[$i];
		my $rh_comb = $output_comb{$sig};
		my @sts = sort keys %$rh_comb;
		my $RHS = "";
		if (@sts != 0) {
			my $st_label = $sts[0];
			$RHS .= qq!(state == $st_label!;
			for (my $j = 1; $j < @sts; $j++) {
				$st_label = $sts[$j];
				$RHS .= qq! || state == $st_label!;
			} 
			$RHS .= qq!)!;
		} else {
			$RHS = "0";
		}
		$string .= qq!assign $sig = $RHS;\n!;
	}

	# initial state
	$st_label = $h_st_map{$init};
	$string .= qq!\ninitial begin \n \tstate = $st_label;\nend\n\n!;
	
	# the state transition table
	$string .= qq!always \@(posedge clk)\n!;
	$string .= qq!\tcase(state)\n!;

	my @trans_keys = sort keys %h_moore_trans;
	my $crt_st = "____";
	my $first_st = 1;

	foreach my $tr_key (@trans_keys) {
		my ($st, $n_inalpha) = split(":", $tr_key);
		next if $h_moore_st{$st} == -1;	

		my $st_code = $h_st_map{$st};
		my $alpha_str = $alpha_str_a[$n_inalpha];
		my @sigs = split("_", $alpha_str);
		my $alpha_str2 = join(" && ", @sigs);
 
		my $n_dst = $h_st_map{ $h_moore_trans{$tr_key} };

		if ($crt_st ne $st) {
			$crt_st = $st;	
			$string .= qq!\tend\n! if (!$first_st);
			$string .= qq!\t$st_code : begin\n!; 			
			$first_st = 0;
		} 
		$string .= qq!\t\tif ($alpha_str2) state = $n_dst;\n!; 
	}

	$string .= qq!\tend\n\tendcase\n\n!;
	$string .= qq!endmodule\n!;

	return $string;
}

sub PutToBiGraph {
	my ($self, $re_fix, $e_alpha, $ra_fix) = @_;
	my $rh_bi_graph = $$self{fix_bigraph};
	my $bg_nodes = $$self{bg_nodes};

	my $src = $$bg_nodes{$re_fix};
	my $dst = $$bg_nodes{$ra_fix};

	my $tmp = $$rh_bi_graph{$src};
	if (!defined $tmp) {
		my %h_nu = ();
		$$rh_bi_graph{$src} = \%h_nu;
		$tmp = \%h_nu;
	}			
	$$tmp{"$e_alpha:$dst"} = 1;

	$tmp = $$rh_bi_graph{$dst};
	if (!defined $tmp) {
		my %h_nu = ();
		$$rh_bi_graph{$dst} = \%h_nu;
		$tmp = \%h_nu;
	}			
	$$tmp{"$e_alpha:$src"} = 1;

	return 1;
}

sub CalculatePostFix {
	my ($self, $player, $rar_fs) = @_;

	my %h_s = $player eq "e_play" ? %{$$self{r_e}} : %{$$self{r_a}};
	my @a_s = sort keys %h_s;
	my $n_alphabets = 2**@a_s;  

	my $retValue = undef;
	my ($ra_Fs, $ra_f) = (undef, undef);
	for (my $i = 0; $i < $n_alphabets; $i++) {
		my $post = $self->CalculatePost($player, $rar_fs, $i);
		$post = $self->RemoveUnSubsumed("e_play", $post) if $player eq "e_play";
		$post = $self->AntiChainMax($post);

		if (!defined $retValue) {
			$retValue = $post if @$post != 0;
		} else {
			$retValue = $self->MaxofUnion($retValue, $post);
		}
	}

	return $retValue;
}

sub CalculatePost {
	my ($self, $player, $rar_fs, $n_alphabets) = @_;

	my %finst = %{$$self{gfga_finSt}};
	my $gfga_q_src = $player eq "e_play" ? $$self{gfga_q_e} : $$self{gfga_q_a} ;
	my $gfga_q_dst = $player eq "e_play" ? $$self{gfga_q_a} : $$self{gfga_q_e} ;
	my @q_src = sort keys %$gfga_q_src;
	my @q_dst = sort keys %$gfga_q_dst;

	my %h_trans = %{$$self{gfga_trans}};
  my %finite = %{$$self{gfga_finSt}};
	my %state_tgts = %{$$self{state_tgts}};
	my %ary = %{$$self{ary}};

	my $k = $self->getCurrentK;
	my @retValue = ();
	my @ar_fs = @$rar_fs;
	foreach my $ra_f (@ar_fs) {
		my @a_f = @$ra_f;

		my @crt_f = ();
		foreach my $qp (@q_dst) {
			push(@crt_f, -1);
		}

		my $validThis = 1;
		foreach my $q (@q_src) {
			next if $a_f[ $ary{$q} ] == -1;
			
			my %q_tgts = %{$state_tgts{$q}};
			my ($qp, $dont_care) = (undef, undef);
			while ( ($qp, $dont_care) =  each(%q_tgts) ) {
				my $trans_exist = $h_trans{"$q:$n_alphabets:$qp"};

				if (defined $trans_exist) {
					my $tmp_value = $a_f[ $ary{$q} ];
					my $fin = $finite{$qp};
					$tmp_value += 1 if defined $fin;

					if ($tmp_value > $k) {
						$validThis = 0;
						last; 
					} elsif ( $tmp_value > $crt_f[ $ary{$qp} ] ) {
						$crt_f[ $ary{$qp} ] = $tmp_value;
					}
				}
			} # end for $qp

			last if !$validThis;
		} # end for #q

		push(@retValue, \@crt_f) if $validThis;
	}

	return \@retValue;  
}

sub RemoveUnSubsumed {
	my ($self, $player, $ra_fs) = @_;

	my $verb = $$self{verbose};
	my $r_antiChain = $player eq "e_play" ? $$self{ra_fix_a} : $$self{ra_fix_e};
	my @a_antiChain = @{ $r_antiChain };
	my @a_fs = @{ $ra_fs };

	my @retValue = ();
	foreach my $r_f (@a_fs) {
		my $validThis = 0;
		foreach my $r_fix (@a_antiChain) {
			my $subsumed = $self->CompareF($r_fix, $r_f);
 			
			if ($subsumed eq "GT" or $subsumed eq "EQ") {
				$validThis = 1;
				last;
			}
		} # end of $r_fix

		push(@retValue, $r_f) if $validThis;
	}
	
	return \@retValue;
}


######################################################################
# Takes the stored transition labeled NBW and a partition of the AP
# into IO-signals and translate it to a UCT.
######################################################################
sub BuildUCT {
  my ($self, $verb) = @_;
  $verb = $$self{verbose} unless defined $verb;
  my $bl   = $self->GetTransitionLabeledNBW;
  my $partition = $$self{partition};
  my $name = $$self{name};
  my $debugdir = $$self{directory};
  my $optimize = $$self{optimize_uct};
  my $merge_edges = $$self{optimize_edges};
  my $valid = 1;

  print "NBW -> UCT...\n";
  my $cb = CoBuechiTree->fromBuechi( $bl, $partition, $verb, $merge_edges );
  if ( $cb eq "" ) {
  	$self->WriteOutputfiles("Formula is not realizable.\n");
		return "";
  }

  if ($verb > 2) {	
	  print "Stats UCT: ", $cb->Stats, "\n";
		open( UCT, ">$debugdir"."uct_unop.dot" );
		print UCT $cb->ToDot($name);
		close UCT;
		Utils::dot2ps($debugdir."uct_unop.dot");
	}

	if ($optimize && $$self{winner} eq "mod") {
	  $valid = $cb->LostStatesMinimization($verb) ;
  	print "Stats UCT LS: ", $cb->Stats, "\n";
		if ($valid eq "") {
		  $self->WriteOutputfiles("Formula is not realizable.\n") ;
			return $valid;
		}
	} else {
		print "Stats UCT LS: ", $cb->Stats, "\n"; 
	}

  $$self{uct} = $cb;
 	print "NBW -> UCT done\n";
 	if ($verb > 2) {
		open( UCT, ">$debugdir"."uct_op.dot" );
		print UCT $cb->ToDot($name);
		close UCT;
		Utils::dot2ps($debugdir."uct_op.dot");
		open UCT,  ">$debugdir"."uct.uct";
		print UCT $cb->ToString;
		close UCT;
 	}

	return 1;
}


######################################################################
# Clean the output files to avoid confusion.
######################################################################
sub CleanOutputfiles {
	my $self = shift;
	my $debugdir = $$self{directory};
	system ("rm -f $debugdir*.ps ");
	system ("rm -f $debugdir*.dot ");
	system ("rm -f $debugdir*.v ");
	system ("rm -f $debugdir*.log ");
}

######################################################################
#
######################################################################
sub GetTransitionLabeledNBW {
    my $self = shift;
    return $$self{nbw_tl} if (defined $$self{nbw_tl});
    die "Transition labeled NBW not computed\n";
}
sub GetNBW {
    my $self = shift;
    return $$self{nbw} if (defined $$self{nbw});
    die "NBW not computed\n";
}

sub WriteOutputfiles {
    my ($self,$text) = @_;
		return;
}

# Autoload methods go after =cut, and are processed by the autosplit program.

sub DESTROY {
	my $self = shift;
	
}

1;
__END__
# Below is stub documentation for your module. You'd better edit it!


