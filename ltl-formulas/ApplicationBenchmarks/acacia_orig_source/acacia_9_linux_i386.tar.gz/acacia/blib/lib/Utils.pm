# $Id: Utils.pm,v 1.1.1.1 2008/10/25 15:13:03 nyjin Exp $

######################################################################
# Functions for debugging
#
# Lily - LInear Logic sYnthesize
# Author: Barbara Jobstmann <bjobst@ist.tugraz.at>
#
######################################################################
package Utils;
use Exporter ();
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $nameIndex $DEBUG);
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw();
$VERSION   = 1.00;
$DEBUG     = -3;

sub dot2ps {
    # If you want to translate the dot-file into ps-file  automatically,
    # uncomment the follwing lines.
     my $file = shift;
     print "dot2ps $file...\n";
     $_="$file"; s/dot/ps/;
     system ("/usr/bin/dot -Tps ".$file." > ".$_." &");
     print "dot2ps $file done\n";
}

# parameters are $n then $d
sub calcBitNum {
    my $r = shift; 
    my $q = 0;
    while ($r > 2) { 
			$r = $r / 2;
			$q = $q + 1;
    }
    return $q;
}

=item print_array

Descirption: To Print the content of an array.

Usage: For a given array @array, then print_array(\@array)

=cut

sub print_array {
	my $r_r = shift;
  my @a_r = @{$r_r};
  my $n_tmp = 0;
  while ($n_tmp < @a_r){
    print "$a_r[$n_tmp] ";
    $n_tmp++;
	}
  return 1;
}

=item int2binary

Descirption: To return an array of digits whose product equals to the input interger 

Usage: int2binary(\@array, $n)

=cut

sub int2binary {
	my ($r_array, $n_num) = @_;
  my $n_tmp = @{$r_array}-1;
  while ($n_tmp >= 0){
    $$r_array[$n_tmp] = $n_num - (($n_num >> 1) << 1);
    $n_num = $n_num >> 1;
    $n_tmp--;
	}

  return 1;
}


1;
