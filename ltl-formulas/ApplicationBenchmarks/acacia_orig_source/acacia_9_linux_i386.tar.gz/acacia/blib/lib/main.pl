#! /usr/bin/perl -w

# This script generates Buechi automata from LTL formulae using
# the Daniele-Giunchiglia-Vardi algorithm and various optimizations.

# Author: Fabio Somenzi <Fabio@Colorado.EDU>, with modifications
# by Roderick Bloem <roderick.bloem@colorado.edu> 
# Barbara Jobstmann <bjobst@ist.tugraz.at> and
# Naiyong Jin <naiyjin@ulb.ac.be>

use strict;
use Sopen;
use LTL;
use LTL2AUT;
use Acacia;

my $startTime = (times)[0];
my $nbwTime = (times)[0];
my $reChkTime = (times)[0];
my $synTime = (times)[0];
my $antichainEndTime = (times)[0];
my $antichainStartTime = (times)[0];
my $endAutomataConst = (times)[0];

# Set default values for options.
my $verb = 1;			# verbosity level
my @formulae = ();		# list of LTL formulae to be processed
my @formulaeAssume = ();	# list of assume formulae to be processed
my $prefix = "ltl2vl";		# prefix for output file names
my $method = "LTL2AUT";		# method (GPVW, GPVW+, LTL2AUT, Boolean)
my $simplify = 1;		# simplify formula
my $optimize = 1;		# optimize automaton
my $complete = 0;		# complete transition relation
my $help     = 0;               # help is requested
my $automaton = "";		# automaton file
my $monitorFile = "";		# Verilog monitor file
my $verify = 0;
my $mink = 0;
my $maxk = 20;
my $winner = "mod";
my $aaInUse = "UCT";

# Set default for building the complement
my $complementA = 0;

# project to a given set of atomic propositions
my $project = 0;
my $projectVars = Set->new;

# Set default for applying the counting construction
my $cc = 0;

# Set default values for synthesis options
my $ltlfile = "";
my $sugar = "";
my $synthesis = 0;
my %partition = ();    # IO-partition
my $synthesisDir = ""; # debug and result directory
my $mc = 0;
my $env = 0;                    # extract restricted environment too
my $env_automaton = "";		# automaton that restricts the environment
my $optimize_uct = 1;		# optimize uct automaton
my $optimize_awt = 1;		# optimize awt automaton
my $optimize_witness = 1;	# optimize witness
my $optimize_mh = 1;	        # optimize MH with simulation relation
my $optimize_edges = 1;
my $optimize_release = 1;
my $optimize_reuse = 1;
my $combinedMH = 1;             # combined MH with witness computation
my $item = "";

# Parse command line and set options accordingly.
while (defined($ARGV[0]) && substr($ARGV[0], 0, 1) eq "-") {
  if ($ARGV[0] eq "-c") {
		shift;
		$complete = shift;
  } elsif ($ARGV[0] eq "-h") {
		shift;
		$help = 1;
  }  elsif ($ARGV[0] eq "-ltl") {
		shift;
		$ltlfile = shift;
		$_ = $ltlfile;
		if (/\.psl/) {
	    print "Read Sugar file.\n";
	    readSugar($_,\@formulae, \@formulaeAssume);
	    $ltlfile =~ s/\.psl/\.ltl/;
	    $sugar = 1;
		} else {
	    print "Read LTL file.\n";
	    readLTLOverSeveralLines($_,\@formulae, \@formulaeAssume);
		}
  } elsif ($ARGV[0] eq "-m") {
		shift;
		$method = shift;
  } elsif ($ARGV[0] eq "-o") {
		shift;
		$optimize = shift;
  } elsif ($ARGV[0] eq "-oedges") {
		shift;
		$optimize_edges = shift;
  } elsif ($ARGV[0] eq "-orelease") {
		shift;
		$optimize_release = shift;
  } elsif ($ARGV[0] eq "-oreuse") {
		shift;
		$optimize_reuse = shift;
  } elsif ($ARGV[0] eq "-owit") {
		shift;
		$optimize_witness = shift;
  } elsif ($ARGV[0] eq "-p") {
		shift;
		$prefix = shift;
  } elsif ($ARGV[0] eq "-s") {
		shift;
		$simplify = shift;
  } elsif ($ARGV[0] eq "-v") {
		shift;
		$verb = shift;
  } elsif ($ARGV[0] eq "-ver") {
		shift;
		$verify = shift;
  } elsif ($ARGV[0] eq "-mon") {
		shift;
		$monitorFile = shift;
  } elsif ($ARGV[0] eq "-syn") {
		$synthesis = 1; 
		shift;
		my $partitionfile = shift;
		readPartition($partitionfile,\%partition);
  } elsif ($ARGV[0] eq "-syndir") {
		shift;
		$synthesisDir = shift; 
		$synthesisDir .= "/";
  } elsif ($ARGV[0] eq "-comp") {
		shift;
		$complementA = 1;
  } elsif ($ARGV[0] eq "-env") {
   	shift;
		$env = shift;
  } elsif ($ARGV[0] eq "-envauto") {
		shift;
		$env_automaton = shift;
		unless ($env_automaton =~ /\.aut|\.l2a/) {
	    print "Wrong file extension of automata file. Use -h for more details.\n";
	    $env_automaton = "";
	    die usage();
		}
  } elsif ($ARGV[0] eq "-pj") {
   	shift;
		$project = 1;
		my $file = shift;
		readPartition($file,\%partition);
		foreach (keys %partition) {
	    if ($partition{$_} eq 2) { #output variable
				$projectVars->Push($_);
	    }
		}
  } elsif ($ARGV[0] eq "-cc") {
   	shift;
		$cc = 1;
  } elsif ($ARGV[0] eq "-k") {
		shift;
		$mink = shift;
		$mink -= 1;  
  } elsif ($ARGV[0] eq "-K") {
		shift;
		$maxk = shift;
  } elsif ($ARGV[0] eq "-w") {
		shift;
		$winner = shift;
  } elsif ($ARGV[0] eq "-a") {
		shift;
		$aaInUse = shift;
  } elsif ($ARGV[0] eq "-mc") {
		shift;
		$mc = shift;
  } else {
		warn "unrecognized option: $ARGV[0]\n";
		shift;
  } 
}

die helpMessage() if $help;
die usage() if (($env_automaton ne "" and $env ne 1) ||
								($env_automaton eq "" and $env eq 1));
die usage() if (@formulae == 0 and $automaton eq "");
die usage() if $#ARGV !=-1 or (@formulae == 0 and $automaton eq "");
die usage() if ($synthesis == 0) or
							 (keys(%partition) == 0 and $synthesis == 1);
die usage() if ($mink < -1) or ($maxk < $mink);
die usage() if ($winner ne "mod") and ($winner ne "env"); 
die usage() if ($aaInUse ne "NBW") and ($aaInUse ne "UCT"); 
  
if ($synthesis) {
	my $formulaAssume = "";
	my $formula = "";
	my $assume="";
  #First build the product of all formulas
	foreach my $form (@formulaeAssume) {
		$assume=1;
		if ($formulaAssume eq "") {
	    $formulaAssume = $form;
		} else {
	    $formulaAssume = "(".$form.")*(".$formulaAssume.")";
		}
		print "assume ".$form."\n" if $verb > 1;
	}

  foreach my $form (@formulae) {
		if ($formula eq "") {
			$formula = $form;
		} else {
			$formula = "(".$form.")*(".$formula.")";
		}
		print "assert ".$form."\n" if $verb > 1;
  }
  
	$formula = "(".$formulaAssume.") -> (".$formula.")" if ($formulaAssume);
  if ($sugar) {
		print "Write LTL equivalent to $ltlfile.\n";
		open(LTLF, ">$ltlfile") or die "Can't open $ltlfile : $!";
		print LTLF $formula.";\n";
		close(LTLF);
	}
	if ($assume) {
		print "Write LTL equivalent to $ltlfile.\n";
		system ("mkdir ".$synthesisDir) if (($synthesisDir ne "") and
					    (not -d $synthesisDir));
		open(LTLF, ">$synthesisDir$ltlfile-mc") or die "Can't open $ltlfile : $!";
		print LTLF $formula.";\n";
		$ltlfile="$synthesisDir$ltlfile-mc";
		close(LTLF);
	}
	

	my $synthesizer = Acacia->new( name      => $ltlfile,
				   formula   => $formula,
				   partition => \%partition,
				   directory => $synthesisDir,
				   prefix    => $prefix,
				   simplify  => $simplify,
				   method    => $method,
				   optimize_nbw  => $optimize,
				   optimize_witness  => $optimize_witness,
				   optimize_edges => $optimize_edges,
				   optimize_release => $optimize_release,
				   optimize_reuse => $optimize_reuse,
				   optimize_uct  => $optimize_uct,
					 aa_in_use => $aaInUse,	
				   verbose   => $verb,
					 minK => $mink,
 					 maxK => $maxk,
					 winner => $winner
				 );

  #clean previous outputfiles to avoid confusion
  $synthesizer->CleanOutputfiles;
    
  # make debug directory
  system ("mkdir ".$synthesisDir) if (($synthesisDir ne "") and
				    (not -d $synthesisDir));
  my $valid;
  $startTime = (times)[0];
  $nbwTime = (times)[0];

  if ($automaton =~ /\.l2a/) {
	  print "Read a transition labeled NBW automaton\n";
	  my $moddate = sopen($automaton,\*AUTOMATON);
	  my $aut = BuechiAL->new(file => \*AUTOMATON);
	  close AUTOMATON;
	  $synthesizer->SetTransitionLabeledNBW($aut);
	  $nbwTime = (times)[0];
	} elsif ($automaton =~ /\.uct/) {
	    print "Read an UCT automaton\n";
	    my $moddate = sopen($automaton,\*AUTOMATON);
	    my $aut = CoBuechiTree->new(file => \*AUTOMATON);
	    close AUTOMATON;
	    $valid = $synthesizer->SetUCT($aut);
	    goto EXIT unless $valid;
  } else {
    print "To build NBW\n";
		$valid = $synthesizer->BuildNBW;
	  my $env_aut;
	  if ($env == 2) {
			print "Compute class-two-realizability\n";
			$env_aut = $synthesizer->BuildPureAssumption($verb);
			$valid = $synthesizer->UseAssumption($env_aut);
	  } elsif ($env == 1) {
				if ($env_automaton =~ /\.aut/) { #automaton
			  	print "Read input assumption (NBW)\n";
			   	my $moddate = sopen($env_automaton,\*AUTOMATON);
			   	$env_aut = Buechi->new(file => \*AUTOMATON);
			   	close AUTOMATON;
			   	$valid = $synthesizer->UseAssumption($env_aut);
				} elsif ($env_automaton =~ /\.l2a/) {
		    	print "Read input assumption (tr-labeled NBW)\n";
		    	my $moddate = sopen($env_automaton,\*AUTOMATON);
		    	my $aut = BuechiAL->new(file => \*AUTOMATON);
		    	close AUTOMATON;
		    	if ($verb > 1) {
						open(ASSUME, ">$synthesisDir"."assume-al.dot");
						print ASSUME $aut->ToDot("Assumption");
						close ASSUME;
		    	}
		    	$env_aut = $aut->ToBuechi;
		    	$valid = $synthesizer->UseAssumption($env_aut);
				} else {
		    	die; #wrong automaton
				}
	  }
	  goto EXIT unless $valid;
	    
	  $synthesizer->ApplyCountingConstruction;
	  $valid = $synthesizer->BuildTransitionLabeledNBW;
	  $nbwTime = (times)[0];	
	  goto EXIT unless $valid;
	  
    $valid = $synthesizer->BuildUCT if $aaInUse eq "UCT";
		my $win = $winner eq "mod" ? "Controller" : "Environment";
		if (!$valid ) {
			print "The $win has no winning strategy !\n";
		}
    goto EXIT unless $valid;
	}

	# nyjin: special codes for Acacia	
	$valid = $synthesizer->BuildGameContext;
	goto EXIT unless $valid;
	print "--xxx--------------------------------------------------------------------\n";

  $valid = $synthesizer->BuildTurnBasedAutomaton;
	goto EXIT unless $valid;

  $endAutomataConst = (times)[0];

	if ($verb > 2) {
		open(TBA, ">$synthesisDir"."tba.dot");
		print TBA $synthesizer->PrintGoodForGameAutomaton("Negation of the formula in $ltlfile");
		close TBA;
		Utils::dot2ps($synthesisDir."tba.dot");
	}
#	goto EXIT;

	$antichainStartTime = (times)[0];	
	$valid = $synthesizer->RealizableTestByAntiChain;
	$antichainEndTime = (times)[0];
#goto EXIT;
	goto EXIT unless $valid;

	$valid = $synthesizer->StrategyConstruction;
	goto EXIT unless $valid;

  print "--xxx-----------------------------------------------------------------\n";

	if ($mc) {
		print "Modelcheck result...\n";
		if ($winner eq "mod") {	
  	 ModelCheck($ltlfile, $synthesisDir);
		} else {
			my $ltl_env = "ltl_env.ltl";
			open(LTL_ENV, ">$ltl_env");
			print LTL_ENV "!(".$formula.");";
			close LTL_ENV;
  	  ModelCheck($ltl_env, $synthesisDir);
		}
		print "done\n";
	}

}

EXIT:

my $endTime = (times)[0];
printf "NBW time: %.5f seconds\n", $nbwTime - $startTime ;
printf "Time for Automata and Game Structure Construction in Total: %.5f seconds\n", $endAutomataConst - $startTime ;
printf "Realizablility Check time: %.5f seconds\n", $antichainEndTime - $antichainStartTime;
printf "Total time: %.5f seconds\n", $endTime - $startTime;

exit(0);

######################################################################
# Build a call-file to model check the synthesis result.
######################################################################
sub ModelCheck {
	my ($ltlfile, $synthesisDir) = @_;
	
	# Set Path to vis modelchecker
#	$ENV{'PATH'} = '/netshares/commons/verify/Software/bin';
		  
	open (CALL, ">$synthesisDir"."call-mc");
	print CALL "read_verilog acacia.v\n";
	print CALL "init_verify\n";

	if ($synthesisDir ne "") {
	    print CALL "ltl_model_check -i -f debug_trace.log -d 1 -s ../$ltlfile\n";
			close CALL;
	    system ("pushd $synthesisDir && vis -x -f call-mc && popd");
	} else {
	    print CALL "ltl_model_check -i -f debug_trace.log -d 1  $ltlfile\n";
			close CALL;
	    system ("vis -x -f call-mc");
	}
#	close CALL;
}

######################################################################
# Read LTL formulae from file and append them to a list. Each formula
# can extend over several lines but has to end with a semicolon.
######################################################################
sub readLTLOverSeveralLines {
    my ($file,$fref,$aref) = @_;
    my $moddate = sopen($file,\*FFILE);
    my $formula ="";
    my $assume = 0;
    my %map;
    
    while (<FFILE>) {
    	print $_;
			chop;					# discard newline
			s/\#.*//;			# discard comments
			s/\s+$//;			# discard trailing blanks
			if (/\\define[\s]+([\w\.\_\d]+) (.+)/) {
	    	my $key = $1;
	    	my $value = $2;
# 	    	print "Definition found: ", $key,"\n";
	    	if ($value =~ /\\/) {
					foreach my $key (keys %map) {
						my $val = $map{$key};
		   			$value =~ s/\\$key/$val/g;
					}
	    	}
	    	#check if the new $key has a sub or super-key
	    	foreach (keys %map) {
					if ((/^$key/) || ($key =~ /^$_/)) {
		    		print "Two define-keys are too similar: $key, $_\n";
		    		exit 1;
					}
	    	}
	    
	    	$map{$key} = $value;
			} else {
	    	$formula .= $_;
	    	if (/;/) {
					$formula =~ s/;//;		# discard trailing semicolon
					$formula =~ s/assert //;    # discard 'assert' keyword
					$assume = 1 if ($formula =~ s/assume //);
					$formula =~ s/\s+$//;	# discard trailing blanks
					if (/\\/) {
# 		    		print "Macros found: ", $formula,"\n";
		    		foreach my $key (keys %map) {
							my $val = $map{$key};
							$formula =~ s/\\$key/$val/g;
		  			}
# 		    		print $formula,"\n";
					}
			
					if ($assume) {
		  	  	push(@$aref,$formula) unless ($formula =~ /^\s*$/);# skip empty lines
					} else { #default
		  	  	push(@$fref,$formula) unless ($formula =~ /^\s*$/);# skip empty lines
					}
					$formula="";
					$assume = 0;
	    	}
			}
    } # end of while
    
    if ($formula ne "") {
       print "Warning reading LTL formulae: Semicolon missing\n";
    } else {
    	print $formula; 
    }
    
    close(FFILE);
} # readLTLOverSeveralLines


######################################################################
# Read IO partitioning from file and store it in a hash table.
# '1' is an input
# '2' is an output
######################################################################
sub	readPartition {
	my ($partitionfile,$partition) = @_;
	open( FILE, $partitionfile);
	my @lines = <FILE>;
	die error("PartitionFileError") if (not @lines);
	close FILE;
	my $iovalue = 0;
	print  @lines." Lines read from partition-file '".$partitionfile."'" if $verb > 1;

L:	foreach my $line (@lines) {
		my @elems = split(/ +/,$line);
		foreach (@elems) {
			next L if (/(\#.*)/);
			if (/( )|(\n)/) {
			  chop;
			}
			next if (not $_);
			if (/\.inputs/) {
				print "\ninputs: ";
				$iovalue = 1;
			} elsif (/\.outputs/) {
				print "\noutputs: ";
				$iovalue = 2;
			} else {
				next if ($iovalue == 0);
				print $_." ";
				$$partition{$_} = $iovalue;
			}
		}
	}
	print "\n";
	die error("PartitionEmpty") if (keys(%$partition) == 0);
} #readPartition


######################################################################
# Return the usage message.
######################################################################
sub error {
	$_ = shift;
	if (not $_) {
		return usage() . "General error\n";
	}
	if (/PartitionFileError/) {
		return usage() . <<EOF;
Error reading partition file.
EOF
	}
	
	if (/LTLFileEmpty/) {
	print usage() . <<EOF;
File containing the ltl formulas is empty.
EOF
	}

	if (/PartitionEmpty/) {
	print usage() . <<EOF;
I/O-partition is empty.
EOF
	}	
}

######################################################################
# Return the usage message.
######################################################################
sub usage {
    return <<EOF;
Usage: $0 [-c {0,1}] [-cc] [-h] [-ltl file]
       [-m method] [-o {0,1}] [-p prefix] [-s {0,1}] [-v n]
       [-ver {0,1}] [-auto file] [-mon file]
       [-syn file] [-syndir synthesisDir] [-mc]
       [-owit {0,1}]
       [-oedges {0,1}] [-orelease {0,1}] [-oreuse {0,1}]
       [-env {0,1,2}] [-pj file] [-envauto file]
       [-k min_k] [-K max_k]

EOF

} # usage


######################################################################
# Return the help message.
######################################################################
sub helpMessage {
    return usage() . <<EOF;

-c {0,1}  : Iff n != 0, make the transition relation of the automaton complete
            (off by default).
-cc       : Apply counting construction
-comp	  : Build Buechi automaton and its complement for the given LTL formula.
-env {0,1,2}: Check different types of realizability
            0 ... realizability (default)
            1 ... realizabily under assumption L (automaton given with -envauto)
            2 ... class-two-realizability
-h        : gives this help.
-ltl file : file containing the LTL formulae to be ranslated.
            Use either -ltl or -f.
-m method : Sets the method used in translation.  Method ranges over
            GPVW, GPVW+, LTL2AUT, Boolean.  Default is Boolean.
-o {0,1}  : Optimize the automaton after translation, using simulation
            relations. On by default.
-owit {0,1}: Optimize the witness/strategy, using simulation
             relations. On by default.
-omh  {0,1}: Use Fritz optimizations during MH construction.
-omhc {0,1}: Combine MH construction with language emptiness check.
-oedges {0,1}: Merge edges
-orelease {0,1}: Restrict release function to stay in odd layer if possible.
-oreuse {0,1}: Reuse the result from previous computations with lower ranks.
-p prefix : Sets the prefix of the files that are written.  Default: ltl2aut.
-pj file  : Project the automaton to the input signals given in the file
-s {0,1}  : Iff n != 0, simplify the formula before translating it, using
            rewriting.  On by default.
-k min_k  :  from which the k starts from (default is 0)
-K max_k  :  terminate the process when max_k + 1 is reached (default is 20)
             max_k >= min_k.
-v n      : Sets the verbosity level (0 <= n <= 4, default is 1).
-ver{0,1} : Iff n!= 0, make an attempt at verifying the automaton.
            Off by default.
-mon file : Write a Verilog monitor to file.
-syn file : Synthesizes the given ltl formula to Verilog code using the 
	    IO-partition stored in the given file.
-syndir dn: Only valid with -syn option. dn is the directory name where all
	    (temporal) results of the synthesis process are stored. Default 
	    value is 'synthesis'.
-mc       : Only valid with -syn option. Modelchecks the result of the 
            synthesis process using VIS.

This is Wring, by Fabio Somenzi, University of Colorado.  No warranty
is given for the correctness of this code or its suitability for any
purpose.  Given an LTL formula, creates a Buechi automaton that
accepts exactly those traces that satisfy the formula.  See [SB00] for
a description of the algorithm.  Wring incorporates the algorithms of
[GPVW95] and [DGV99], as special cases.  The program writes three
files: prefix-parse.dot, prefix-buechi.dot, and prefix-scc.dot.  These
files hold the graphs of the parse tree, the Buechi automaton, and the
SCC-quotient graphs of the automaton respectively.  They are in dot
format, which can be translated using dot.  Please learn the syntax of
LTL formulae from the examples below.

Examples:

ltl2aut.pl -f '!(p=1 U (q=1 U r=1))' -p wring
Produces the automaton for the formula using wring, the strongest algorithm.
Equivalent to:
ltl2aut.pl -f '!(p=1 U (q=1 U r=1))' -p wring -m Boolean -s 1 -o 1

ltl2aut.pl -f '(G(F(p=1))) -> (G(F(q=1)))' -p wring -s 0 -o 0 -m LTL2AUT -v 4
Produces the automaton for the formula in the manner of [DGV99].

ltl2aut.pl -f '(F(p=1)) U (G(q=1))' -p wring -s 0 -o 0 -m GPVW -v 0
Produces the automaton for the formula in the manner of [GPVW95].

NB: The algorithm uses hash tables extensively, which makes it sensitive to
memory issues.  Results may be different between a run that uses -s 1 and and
run that does not, even though -s 1 is the default, because specifying options
shifts data in memory.

EOF

} # helpMessage
